SET NAMES UTF8;
DROP DATABASE IF EXISTS dj;
#创建dj数据库
CREATE DATABASE dj CHARSET=UTF8;
USE dj;
#创建数据表
#用户数据表
CREATE TABLE dj_user(
    id INT PRIMARY KEY AUTO_INCREMENT,
    iphone VARCHAR(15) NULL ,
    email VARCHAR(25) NULL ,
    upwd VARCHAR (256)
);
#商品类别表
CREATE  TABLE nav_type(
    nid INT  PRIMARY KEY AUTO_INCREMENT ,
    type VARCHAR(32),
    img VARCHAR (64),
    bgimg VARCHAR (64)
);
#商品显示表
CREATE  TABLE  show_shop(
    sid INT PRIMARY KEY  AUTO_INCREMENT,
    sort VARCHAR(32),
    type VARCHAR (32),
    img VARCHAR (128),
    video VARCHAR (128) DEFAULT NULL,
    title VARCHAR (128),
    price DECIMAL (5,0)
);
#商品表
CREATE TABLE shop(
    mid INT  PRIMARY KEY  AUTO_INCREMENT,
    type VARCHAR (32),
    img VARCHAR (64),
    changeimg VARCHAR (64),
    title VARCHAR (128),
    price DECIMAL (5,0), 
    show_shopId INT ,
    #外键显示商品表
    foreign key(show_shopId) references show_shop(sid)
);
#商品列表
CREATE TABLE shop_search(
    seid INT PRIMARY KEY AUTO_INCREMENT,
    type VARCHAR (32),
    img VARCHAR (64),
    changeimg VARCHAR (64),
    title VARCHAR (128),
    price DECIMAL (5,0)
);
#增值服务表
CREATE TABLE fw_shop(
    mid INT  PRIMARY KEY  AUTO_INCREMENT,
    type VARCHAR (32),
    img VARCHAR (64),
    price DECIMAL (5,0)
);
#商品详情表
CREATE TABLE dj_laptop(
    lid INT(11) NOT NULL,
    family_id INT(11) DEFAULT NULL,
    type VARCHAR(64) DEFAULT NULL,
    title VARCHAR(128) DEFAULT NULL,
    price DECIMAL(10,2) DEFAULT NULL,
    spec VARCHAR(64) DEFAULT NULL,
    specprice VARCHAR(64) DEFAULT NULL
);
#插入数据---------------------------------------------------------------
#用户数据
INSERT INTO dj_user VALUES(1,'17708355901','1034262909@qq.com',md5('123456'));
#商品列表
INSERT INTO shop_search VALUES (NULL,"DJI Mini 2","d54dd75147fee25c86b9b3639e3c316d@retina_small.png","06e322c2fe32c04a3154c4f6c08a6438@origin.jpg","小巧但性能犀利，可拍摄4K视频，实现4倍变焦，最远10公里控制距离。一键短片、一键全景，一键直出大片。智能易用，航拍轻而易举。","2899");
INSERT INTO shop_search VALUES (NULL,"御Mavic Air 2",	"7727599c23f26f2fa55ab60494cd3569@retina_small.png","03cf5b56f0c3520e87bf21ada53aac9a@origin.jpg","可拍摄 8K 延时影片，4K/60fps 视频，4800 万像素照片。拥有最长 34 分钟续航，最远 10 公里图传距离，焦点跟随功能，支持自行避障。",	"4999");
INSERT INTO shop_search VALUES (NULL,"御Mavic 2","55e19eff-2d6a-4d75-8e63-b9b5822fd298@retina_small.png","c3308478959391aefb1b656946f1b41a@origin.jpg","画质旗舰，变焦先锋。新一代消费级航拍旗舰之作。","9888");
INSERT INTO shop_search VALUES (NULL,"御Mavic Mini","ebb908b85f9f48dbabf5e58a79a74016@retina_small.png","62d6e76f88c7d8c4f0904b920d428465@origin.jpg","御 Mini 将强大飞行性能注入轻小机身中，可随时伴你出行，配合全新 DJI Fly app，助你畅快飞行，随心创作。","2699");
INSERT INTO shop_search VALUES (NULL,"DJI 带屏遥控器","6d50b412-d52a-4b24-b74b-519cd4a4dea7@retina_small.png","363b460c-db2a-40d1-9a0e-26625f0ae6e9.jpg","DJI 带屏遥控器集便携遥控和高亮显示于一身，专为户外航拍设计，全面提升飞行、拍摄体验。","3988");
INSERT INTO shop_search VALUES (NULL,"DJI Air 2S ND 镜套装","e7c631ab75d4be3ff076c12a68736f45@retina_small.png","b93527c9a0e41af4ab271751eb642dd0@origin.jpg","提供更多创作可能的 ND 镜套装。","549");
INSERT INTO shop_search VALUES (NULL,"御Mavic Air 2智能飞行电池",	"74ef9086f33e63f7ee5f040c70401c14@retina_small.png","fcbf99cbc00e00515b0c2583198f2d59@origin.jpg","3 芯高能锂电，31 分钟续航（搭配 DJI Air 2S）/ 34 分钟续航（搭配 Mavic Air 2）。","699");
INSERT INTO shop_search VALUES (NULL,"大疆迷你小背包+","55c4c1fda89614f3db10d5f9e1a052c9@retina_small.png","d96da21269a379663e8ab45622f43f43@origin.jpg","时尚小背包，能容纳并展示 DJI Mini 2 飞行器及其核心配件。","249");
INSERT INTO shop_search VALUES (NULL ,"DJI OM 4","4580e6d2f4a71784866be9fa97ee3aeb@retina_small.png","76d1148c7f6f358e299dc8c33c9000e3@origin.jpg","DJI OM 4 手机云台采用磁吸快拆设计，可迅速装上手机进行拍摄；配合加倍易用的智能拍摄功能，助你轻松创作令人艳羡的华丽影片。","899");
INSERT INTO shop_search VALUES (NULL ,"灵眸Osmo 口袋云台相机","facbf19a7c8e86e782117fee55a64f41@retina_small.png","f2ddbb40c5579391b534b87e768df5ad@origin.jpg","轻巧，便携，智能且配备独立屏幕，轻松拍摄，记录生活从此变得简单又好玩。","1999");
INSERT INTO shop_search VALUES (NULL ,"灵眸运动相机","ed213365e2222a55012758b2cbe7a7a1@retina_small.png","33ffcde840405436f5563b16425e2550@origin.jpg","灵眸运动相机拥有前后双屏，可以自由切换拍摄视角，强大的 RockSteady 增稳技术可大幅滤除画面抖动，拍摄稳定流畅的 4K 视频。","1799");
INSERT INTO shop_search VALUES (NULL ,"Osmo Mobile 灵眸手机云台3","c2124224-91e0-4227-b48b-5faf4673940c@retina_small.png","e0666e04cb976f3557e8407e7630bce8@origin.jpg","灵眸手机云台 3 采用可折叠设计，轻巧便携。三轴机械云台可实现无损防抖，丰富的智能模式，轻松应对日常记录和旅行拍摄。","549");
INSERT INTO shop_search VALUES (NULL ,"DJI Pocket 2全能手柄","540daaf7492ac55a222dd3307c0adedc@retina_small.png","0bbe78d0e8f4c685aecf4f2f5b2dfd26@origin.jpg","支持无线连接手机、无线录制声音，外接耳机或麦克风，和配件拓展。","599");
INSERT INTO shop_search VALUES (NULL ,"Osmo Pocket 加长杆","9fa353cf82535bb99011e136790181f4@retina_small.png","57898316a6869ba8d44352fdc350b346@origin.jpg","可伸缩设计，可搭载手机和三脚架等更多配件，从容应对多样拍摄需求。","399");
INSERT INTO shop_search VALUES (NULL ,"Osmo Pocket 磁吸 ND 减光镜套件","0801a82f4beeaabd2098d25ccf45784b@retina_small.png","aa0f9062-8c18-4233-9e12-1dfc0e9860c3.jpg","可还原真实色彩，满足高阶摄影用户对于精细调整快门速度的需求。","299");
INSERT INTO shop_search VALUES (NULL ,"DJI Pocket 手机夹","2bcac47b5a34c1671216068f8fc38ea1@retina_small.png","2bcac47b5a34c1671216068f8fc38ea1@retina_small.png","","299");
INSERT INTO shop_search VALUES (NULL ,"DJI RSC 2","96cddfc3dbe070d6de61ae7657d8f826@retina_small.png","0b1a1870435879217882200c1637f894@origin.jpg","DJI RSC 2 采用独特的可折叠设计，机身更加紧凑，增稳效果却依旧出众，且提供丰富的拍摄功能。它的各项改进，都将帮你点亮更多创造力，拍出拿手好戏。","2699");
INSERT INTO shop_search VALUES (NULL ,"Ronin SC 如影SC单手持微单稳定器","4abd7d0f977ad71a4e0481d044afa1c0@retina_small.png","56c6fd03d8df5937472dee0719b1d5e4@origin.jpg","Ronin SC 如影 SC 单手持微单稳定器","1299");
INSERT INTO shop_search VALUES (NULL ,"如影Ronin-S","e112765fd82f4d6fe664751c67635838@retina_small.png","e0f659ad508a80f61fc34f28847722ed@origin.jpg","专为单反和微单打造，多场景便携操作，单人也能完成专业拍摄。","3999");
INSERT INTO shop_search VALUES (NULL ,"如影 Ronin 2 专业套装","f2a415b465c12776dc0ffe8be6a446f1@retina_small.png","7f861154-fb14-4772-8258-695cfec1ed7f.jpg","动力全面提升，不仅能搭载更重的摄影机和镜头，而且能承受高速运动中的风阻与惯性，无论手持、车载或是机载，都能时刻提供稳定影像。","46999");
INSERT INTO shop_search VALUES (NULL ,"DJI R 竖拍相机固定组件","60af211e4b62348d7b4115d0f14d2769@retina_small.png","f8c5cc99fea8d4f933f6a8a2302004cf@origin.jpg","可在长时间竖拍时使用。","249");
INSERT INTO shop_search VALUES (NULL ,"DJI 多形态双手持套装","972b42ccb34c31e615d4d7eda4e907bf@retina_small.png","42e13b83f4b98eb0a3199f9822d284f3@origin.jpg","支持快速拆装，可双手握持稳定器进行拍摄，在双手持形态下无需拆卸即可快速切换低角度手提形态。","699");
INSERT INTO shop_search VALUES (NULL ,"DJI Ronin 控制手柄","6616644fc97afc172b66fb73c24424be@retina_small.png","265c5cd2b3cb9d366c7a6d3ba537d60a@origin.jpg","控制手柄上可实现休眠、录像、摇杆、跟焦等一系列操作。","1999");
INSERT INTO shop_search VALUES (NULL ,"DJI Ronin 载具扩展配件包","f844b0a16f629f6db0eda3c44672b8ee@retina_small.png","adabf32e57d41ff3be06b73fb1640d4a@origin.jpg","适配 DJI RS 2，可以实现远距离遥控和供电功能，适用于车载、滑轨、索道、摇臂等拍摄场景。","2999");
INSERT INTO shop_search VALUES (NULL ,"Phantom 4 系列智能飞行电池","8c0be49b126071cf7ef0e52367daa5b1@retina_small.png","d67aaffd-9288-4788-bce7-c1da4d604b9b.jpg","提供30分钟飞行时间","999");
INSERT INTO shop_search VALUES (NULL ,"Phantom 4 系列降噪螺旋桨","e8fed20a-5778-460f-ade5-88ec46191eb3@retina_small.png","8594bace-54d3-484f-80be-5ec62bbb3f77.jpg","全新气动设计，出色降噪表现","59");
INSERT INTO shop_search VALUES (NULL ,"Phantom 4 系列电池管家","6381----c@retina_small.png","a682e493-9cf6-4a37-b38d-c30b46ae5b9c.jpg","三电齐充，便捷省心","499");
INSERT INTO shop_search VALUES (NULL ,"Phantom 4 系列桨叶保护罩","8ea85e1f-7aa9-4204-8a5e-f0a8aab427c8@retina_small.png","9be46374-ace7-428b-900d-30ebba270c35.jpg","Phantom 4 系列桨叶保护罩","99");
INSERT INTO shop_search VALUES (NULL ,"禅思Zenmuse X7(不含镜头)","75b3afb9-0ff1-483d-9ba7-bbca61c79e4e@retina_small.png","cbf1466f-194f-4e66-82de-03e003934251.jpg","影像新高度","16999");
INSERT INTO shop_search VALUES (NULL ,"Zenmuse X7 DL/DL-S镜头套装","e76cd84c-027e-45c4-b027-d6b2767c8b21@retina_small.png","e76cd84c-027e-45c4-b027-d6b2767c8b21@retina_small.png","","26999");
INSERT INTO shop_search VALUES (NULL ,"悟Inspire 2  TB50智能飞行电池","36cdadd0-d955-4324-804c-9b9a44cd0140@retina_small.png","58b324a9-f0e2-4f00-845c-8fb3150c7790.jpg","建议成对购买使用，最长可飞25分钟（搭载禅思X5S云台相机）","999");
INSERT INTO shop_search VALUES (NULL ,"悟Inspire 2 快拆浆","5ac2f0a0-a440-46eb-9527-862b4fe66175@retina_small.png","a826d366-16e3-4047-97a7-271fde796c4c.png","快速拆装，强劲拉力，出色动平衡。","99");
INSERT INTO shop_search VALUES (NULL ,"禅思Zenmuse X5S","4e7e8e3a-1220-4251-9a58-cd3de8fa35fe@retina_small.png","2e5fff5a-5fd1-401b-b737-51990faa7c9c.jpg","M4/3 | 5.2K | F1.7 - F16 | CinemaDNG | ProRes","12499");
INSERT INTO shop_search VALUES (NULL ,"Cendence 遥控器","ae4561fb-d7d8-4d55-ba36-87d52f1d5206@retina_small.png","77624f33-238e-4fa4-ab38-f5593b42f6e6.jpg","","6799");
INSERT INTO shop_search VALUES (NULL ,"DJI电池管理站","5178e212-3c28-4313-867f-09f049794f34@retina_small.png","412d745b-f418-4c3e-9062-50a4cd3c6e9d.jpg","一站式解决充电、储存、运输，高效地管理电池。","7699");
INSERT INTO shop_search VALUES (NULL ,"Inspire 2 手持套件","6e29b04bd83900fe66ea05f22b5268ab@retina_small.png","4e0910e9-a80b-4422-bb4e-c9bccda19d9d.jpg","“天地一体”拍摄，游刃有余。","899");
INSERT INTO shop_search VALUES (NULL,"DJI Mini 2","d54dd75147fee25c86b9b3639e3c316d@retina_small.png","06e322c2fe32c04a3154c4f6c08a6438@origin.jpg","小巧但性能犀利，可拍摄4K视频，实现4倍变焦，最远10公里控制距离。一键短片、一键全景，一键直出大片。智能易用，航拍轻而易举。","2899");
INSERT INTO shop_search VALUES (NULL,"御Mavic Air 2",	"7727599c23f26f2fa55ab60494cd3569@retina_small.png","03cf5b56f0c3520e87bf21ada53aac9a@origin.jpg","可拍摄 8K 延时影片，4K/60fps 视频，4800 万像素照片。拥有最长 34 分钟续航，最远 10 公里图传距离，焦点跟随功能，支持自行避障。",	"4999");
INSERT INTO shop_search VALUES (NULL,"御Mavic 2","55e19eff-2d6a-4d75-8e63-b9b5822fd298@retina_small.png","c3308478959391aefb1b656946f1b41a@origin.jpg","画质旗舰，变焦先锋。新一代消费级航拍旗舰之作。","9888");
INSERT INTO shop_search VALUES (NULL,"御Mavic Mini","ebb908b85f9f48dbabf5e58a79a74016@retina_small.png","62d6e76f88c7d8c4f0904b920d428465@origin.jpg","御 Mini 将强大飞行性能注入轻小机身中，可随时伴你出行，配合全新 DJI Fly app，助你畅快飞行，随心创作。","2699");
INSERT INTO shop_search VALUES (NULL,"DJI 带屏遥控器","6d50b412-d52a-4b24-b74b-519cd4a4dea7@retina_small.png","363b460c-db2a-40d1-9a0e-26625f0ae6e9.jpg","DJI 带屏遥控器集便携遥控和高亮显示于一身，专为户外航拍设计，全面提升飞行、拍摄体验。","3988");
INSERT INTO shop_search VALUES (NULL,"DJI Air 2S ND 镜套装","e7c631ab75d4be3ff076c12a68736f45@retina_small.png","b93527c9a0e41af4ab271751eb642dd0@origin.jpg","提供更多创作可能的 ND 镜套装。","549");
INSERT INTO shop_search VALUES (NULL,"御Mavic Air 2智能飞行电池",	"74ef9086f33e63f7ee5f040c70401c14@retina_small.png","fcbf99cbc00e00515b0c2583198f2d59@origin.jpg","3 芯高能锂电，31 分钟续航（搭配 DJI Air 2S）/ 34 分钟续航（搭配 Mavic Air 2）。","699");
INSERT INTO shop_search VALUES (NULL,"大疆迷你小背包+","55c4c1fda89614f3db10d5f9e1a052c9@retina_small.png","d96da21269a379663e8ab45622f43f43@origin.jpg","时尚小背包，能容纳并展示 DJI Mini 2 飞行器及其核心配件。","249");
INSERT INTO shop_search VALUES (NULL ,"DJI OM 4","4580e6d2f4a71784866be9fa97ee3aeb@retina_small.png","76d1148c7f6f358e299dc8c33c9000e3@origin.jpg","DJI OM 4 手机云台采用磁吸快拆设计，可迅速装上手机进行拍摄；配合加倍易用的智能拍摄功能，助你轻松创作令人艳羡的华丽影片。","899");
INSERT INTO shop_search VALUES (NULL ,"灵眸Osmo 口袋云台相机","facbf19a7c8e86e782117fee55a64f41@retina_small.png","f2ddbb40c5579391b534b87e768df5ad@origin.jpg","轻巧，便携，智能且配备独立屏幕，轻松拍摄，记录生活从此变得简单又好玩。","1999");
INSERT INTO shop_search VALUES (NULL ,"灵眸运动相机","ed213365e2222a55012758b2cbe7a7a1@retina_small.png","33ffcde840405436f5563b16425e2550@origin.jpg","灵眸运动相机拥有前后双屏，可以自由切换拍摄视角，强大的 RockSteady 增稳技术可大幅滤除画面抖动，拍摄稳定流畅的 4K 视频。","1799");
INSERT INTO shop_search VALUES (NULL ,"Osmo Mobile 灵眸手机云台3","c2124224-91e0-4227-b48b-5faf4673940c@retina_small.png","e0666e04cb976f3557e8407e7630bce8@origin.jpg","灵眸手机云台 3 采用可折叠设计，轻巧便携。三轴机械云台可实现无损防抖，丰富的智能模式，轻松应对日常记录和旅行拍摄。","549");
INSERT INTO shop_search VALUES (NULL ,"DJI Pocket 2全能手柄","540daaf7492ac55a222dd3307c0adedc@retina_small.png","0bbe78d0e8f4c685aecf4f2f5b2dfd26@origin.jpg","支持无线连接手机、无线录制声音，外接耳机或麦克风，和配件拓展。","599");
INSERT INTO shop_search VALUES (NULL ,"Osmo Pocket 加长杆","9fa353cf82535bb99011e136790181f4@retina_small.png","57898316a6869ba8d44352fdc350b346@origin.jpg","可伸缩设计，可搭载手机和三脚架等更多配件，从容应对多样拍摄需求。","399");
INSERT INTO shop_search VALUES (NULL ,"Osmo Pocket 磁吸 ND 减光镜套件","0801a82f4beeaabd2098d25ccf45784b@retina_small.png","aa0f9062-8c18-4233-9e12-1dfc0e9860c3.jpg","可还原真实色彩，满足高阶摄影用户对于精细调整快门速度的需求。","299");
INSERT INTO shop_search VALUES (NULL ,"DJI Pocket 手机夹","2bcac47b5a34c1671216068f8fc38ea1@retina_small.png","2bcac47b5a34c1671216068f8fc38ea1@retina_small.png","","299");
INSERT INTO shop_search VALUES (NULL ,"DJI RSC 2","96cddfc3dbe070d6de61ae7657d8f826@retina_small.png","0b1a1870435879217882200c1637f894@origin.jpg","DJI RSC 2 采用独特的可折叠设计，机身更加紧凑，增稳效果却依旧出众，且提供丰富的拍摄功能。它的各项改进，都将帮你点亮更多创造力，拍出拿手好戏。","2699");
INSERT INTO shop_search VALUES (NULL ,"Ronin SC 如影SC单手持微单稳定器","4abd7d0f977ad71a4e0481d044afa1c0@retina_small.png","56c6fd03d8df5937472dee0719b1d5e4@origin.jpg","Ronin SC 如影 SC 单手持微单稳定器","1299");
INSERT INTO shop_search VALUES (NULL ,"如影Ronin-S","e112765fd82f4d6fe664751c67635838@retina_small.png","e0f659ad508a80f61fc34f28847722ed@origin.jpg","专为单反和微单打造，多场景便携操作，单人也能完成专业拍摄。","3999");
INSERT INTO shop_search VALUES (NULL ,"如影 Ronin 2 专业套装","f2a415b465c12776dc0ffe8be6a446f1@retina_small.png","7f861154-fb14-4772-8258-695cfec1ed7f.jpg","动力全面提升，不仅能搭载更重的摄影机和镜头，而且能承受高速运动中的风阻与惯性，无论手持、车载或是机载，都能时刻提供稳定影像。","46999");
INSERT INTO shop_search VALUES (NULL ,"DJI R 竖拍相机固定组件","60af211e4b62348d7b4115d0f14d2769@retina_small.png","f8c5cc99fea8d4f933f6a8a2302004cf@origin.jpg","可在长时间竖拍时使用。","249");
INSERT INTO shop_search VALUES (NULL ,"DJI 多形态双手持套装","972b42ccb34c31e615d4d7eda4e907bf@retina_small.png","42e13b83f4b98eb0a3199f9822d284f3@origin.jpg","支持快速拆装，可双手握持稳定器进行拍摄，在双手持形态下无需拆卸即可快速切换低角度手提形态。","699");
INSERT INTO shop_search VALUES (NULL ,"DJI Ronin 控制手柄","6616644fc97afc172b66fb73c24424be@retina_small.png","265c5cd2b3cb9d366c7a6d3ba537d60a@origin.jpg","控制手柄上可实现休眠、录像、摇杆、跟焦等一系列操作。","1999");
INSERT INTO shop_search VALUES (NULL ,"DJI Ronin 载具扩展配件包","f844b0a16f629f6db0eda3c44672b8ee@retina_small.png","adabf32e57d41ff3be06b73fb1640d4a@origin.jpg","适配 DJI RS 2，可以实现远距离遥控和供电功能，适用于车载、滑轨、索道、摇臂等拍摄场景。","2999");
INSERT INTO shop_search VALUES (NULL ,"Phantom 4 系列智能飞行电池","8c0be49b126071cf7ef0e52367daa5b1@retina_small.png","d67aaffd-9288-4788-bce7-c1da4d604b9b.jpg","提供30分钟飞行时间","999");
INSERT INTO shop_search VALUES (NULL ,"Phantom 4 系列降噪螺旋桨","e8fed20a-5778-460f-ade5-88ec46191eb3@retina_small.png","8594bace-54d3-484f-80be-5ec62bbb3f77.jpg","全新气动设计，出色降噪表现","59");
INSERT INTO shop_search VALUES (NULL ,"Phantom 4 系列电池管家","6381----c@retina_small.png","a682e493-9cf6-4a37-b38d-c30b46ae5b9c.jpg","三电齐充，便捷省心","499");
INSERT INTO shop_search VALUES (NULL ,"Phantom 4 系列桨叶保护罩","8ea85e1f-7aa9-4204-8a5e-f0a8aab427c8@retina_small.png","9be46374-ace7-428b-900d-30ebba270c35.jpg","Phantom 4 系列桨叶保护罩","99");
INSERT INTO shop_search VALUES (NULL ,"禅思Zenmuse X7(不含镜头)","75b3afb9-0ff1-483d-9ba7-bbca61c79e4e@retina_small.png","cbf1466f-194f-4e66-82de-03e003934251.jpg","影像新高度","16999");
INSERT INTO shop_search VALUES (NULL ,"Zenmuse X7 DL/DL-S镜头套装","e76cd84c-027e-45c4-b027-d6b2767c8b21@retina_small.png","e76cd84c-027e-45c4-b027-d6b2767c8b21@retina_small.png","","26999");
INSERT INTO shop_search VALUES (NULL ,"悟Inspire 2  TB50智能飞行电池","36cdadd0-d955-4324-804c-9b9a44cd0140@retina_small.png","58b324a9-f0e2-4f00-845c-8fb3150c7790.jpg","建议成对购买使用，最长可飞25分钟（搭载禅思X5S云台相机）","999");
INSERT INTO shop_search VALUES (NULL ,"悟Inspire 2 快拆浆","5ac2f0a0-a440-46eb-9527-862b4fe66175@retina_small.png","a826d366-16e3-4047-97a7-271fde796c4c.png","快速拆装，强劲拉力，出色动平衡。","99");
INSERT INTO shop_search VALUES (NULL ,"禅思Zenmuse X5S","4e7e8e3a-1220-4251-9a58-cd3de8fa35fe@retina_small.png","2e5fff5a-5fd1-401b-b737-51990faa7c9c.jpg","M4/3 | 5.2K | F1.7 - F16 | CinemaDNG | ProRes","12499");
INSERT INTO shop_search VALUES (NULL ,"Cendence 遥控器","ae4561fb-d7d8-4d55-ba36-87d52f1d5206@retina_small.png","77624f33-238e-4fa4-ab38-f5593b42f6e6.jpg","","6799");
INSERT INTO shop_search VALUES (NULL ,"DJI电池管理站","5178e212-3c28-4313-867f-09f049794f34@retina_small.png","412d745b-f418-4c3e-9062-50a4cd3c6e9d.jpg","一站式解决充电、储存、运输，高效地管理电池。","7699");
INSERT INTO shop_search VALUES (NULL ,"Inspire 2 手持套件","6e29b04bd83900fe66ea05f22b5268ab@retina_small.png","4e0910e9-a80b-4422-bb4e-c9bccda19d9d.jpg","“天地一体”拍摄，游刃有余。","899");
#商品类别
INSERT INTO nav_type VALUES(Null,'御Mavic','mavic2.svg','c23675197790afff3b88d4e495564959.jpg');
INSERT INTO nav_type VALUES(NULL,'灵眸Osmo','ic-Tiny-70x56.svg','6171bd40e7565dad4314ea85a88b17f7.jpg');
INSERT INTO nav_type VALUES(NULL,'精灵Phantom','phantom.svg','ffa803fb88043e4239f7643c4f75cc24.jpg');
INSERT INTO nav_type VALUES(NULL,'如影Ronin','de75be6aa8725b0d70b9f367a36381e6.svg','111ec20dde03cbe72f9ae51adc9e8aba.jpg');
INSERT INTO nav_type VALUES(NULL,'机甲大师','53e4f4dd7d74f6ee7bff1ccd8b54cc86.svg','610e2aed79b3419d78386bfb2635f18e.jpg');
INSERT INTO nav_type VALUES(NULL,'悟Inspire','inspire.svg','series-inspire-kv_2x.jpg');
INSERT INTO nav_type VALUES(NULL,'行业应用','c856e5d1f16c645fd71841008f1c2504.svg','6a52b3328e56a005ea007dd8ee6e1882.jpg');
INSERT INTO nav_type VALUES(NULL,'睿炽科技|特洛','tello.svg','tello-SHOP-banner-PC.jpg');
INSERT INTO nav_type VALUES(NULL,'增值服务','service.svg','85bf8d9639cfd65e7f4d9f6dd8eb0c31.jpg');
INSERT INTO nav_type VALUES(NULL,'创意周边','others.svg','');
#显示商品表
INSERT INTO show_shop VALUES (NULL,'御Mavic',"DJI AIR 2S","767191572ee74ba97f009ee053b754ee@retina_small.png","2ae42d107b30013944df787b8ab113e3.mp4","DJI Air 2S，一英寸相机，大师镜头，5.4K 超高清视频等强悍性能，满足你对旅行航拍的所有想象","6499");
INSERT INTO show_shop VALUES (NULL ,'灵眸Osmo',"DJI Pocket 2","39fe92f56e58f2766794d8665df8db93@retina_small.png","c951d280c126013949e1787b8ab113e3.mp4","小巧便携， 随时带在身边。采用机械增稳技术，可拍摄 4K 视频，6400 万像素照片，自动美颜，还支持立体收音和一键剪辑，让你秒出大片。","2999");
INSERT INTO show_shop VALUES (NULL ,'如影Ronin',"DJI RS 2","9ab930442d4d59ec1304eb6746d254dc@thumb.jpg","djistore_20201013_1200800.mp4" ,"DJI RS 2 采用碳纤维轴臂，机身仅重 1.3 kg，可负载专业摄影机，内置触控彩屏，更可通过配件扩展为摇臂、拍摄车等方案，轻松应对各种拍摄场景。","4999");
INSERT INTO show_shop VALUES (NULL ,"精灵Phantom","精灵Phantom 4 Pro V2.0","e22f7a8005eedf674c6f997b9a1fa471@retina_small.png","djistore_20200106_1200800new.mp4" ,"搭载1英寸 2000万像素Exmor R CMOS传感器，更长的续航，更智能的操控。","9999");
INSERT INTO show_shop VALUES (NULL ,"悟Inspire","悟 Inspire 2","275cd727-41ae-4a46-af32-a1d9274cd9ce@retina_small.png","c951d280c126013949e1787b8ab113e3.mp4" ,"出色的成像质量、强悍的飞行能力以及智能操控体验，为专业影视制作而生。","19999");
#商品数据
INSERT INTO shop VALUES (NULL,"DJI Mini 2","d54dd75147fee25c86b9b3639e3c316d@retina_small.png","06e322c2fe32c04a3154c4f6c08a6438@origin.jpg","小巧但性能犀利，可拍摄4K视频，实现4倍变焦，最远10公里控制距离。一键短片、一键全景，一键直出大片。智能易用，航拍轻而易举。","2899",1);
INSERT INTO shop VALUES (NULL,"御Mavic Air 2",	"7727599c23f26f2fa55ab60494cd3569@retina_small.png","03cf5b56f0c3520e87bf21ada53aac9a@origin.jpg","可拍摄 8K 延时影片，4K/60fps 视频，4800 万像素照片。拥有最长 34 分钟续航，最远 10 公里图传距离，焦点跟随功能，支持自行避障。",	"4999",1);
INSERT INTO shop VALUES (NULL,"御Mavic 2","55e19eff-2d6a-4d75-8e63-b9b5822fd298@retina_small.png","c3308478959391aefb1b656946f1b41a@origin.jpg","画质旗舰，变焦先锋。新一代消费级航拍旗舰之作。","9888",1);
INSERT INTO shop VALUES (NULL,"御Mavic Mini","ebb908b85f9f48dbabf5e58a79a74016@retina_small.png","62d6e76f88c7d8c4f0904b920d428465@origin.jpg","御 Mini 将强大飞行性能注入轻小机身中，可随时伴你出行，配合全新 DJI Fly app，助你畅快飞行，随心创作。","2699",1);
INSERT INTO shop VALUES (NULL,"DJI 带屏遥控器","6d50b412-d52a-4b24-b74b-519cd4a4dea7@retina_small.png","363b460c-db2a-40d1-9a0e-26625f0ae6e9.jpg","DJI 带屏遥控器集便携遥控和高亮显示于一身，专为户外航拍设计，全面提升飞行、拍摄体验。","3988",1);
INSERT INTO shop VALUES (NULL,"DJI Air 2S ND 镜套装","e7c631ab75d4be3ff076c12a68736f45@retina_small.png","b93527c9a0e41af4ab271751eb642dd0@origin.jpg","提供更多创作可能的 ND 镜套装。","549",1);
INSERT INTO shop VALUES (NULL,"御Mavic Air 2智能飞行电池",	"74ef9086f33e63f7ee5f040c70401c14@retina_small.png","fcbf99cbc00e00515b0c2583198f2d59@origin.jpg","3 芯高能锂电，31 分钟续航（搭配 DJI Air 2S）/ 34 分钟续航（搭配 Mavic Air 2）。","699",1);
INSERT INTO shop VALUES (NULL,"大疆迷你小背包+","55c4c1fda89614f3db10d5f9e1a052c9@retina_small.png","d96da21269a379663e8ab45622f43f43@origin.jpg","时尚小背包，能容纳并展示 DJI Mini 2 飞行器及其核心配件。","249",1);
INSERT INTO shop VALUES (NULL ,"DJI OM 4","4580e6d2f4a71784866be9fa97ee3aeb@retina_small.png","76d1148c7f6f358e299dc8c33c9000e3@origin.jpg","DJI OM 4 手机云台采用磁吸快拆设计，可迅速装上手机进行拍摄；配合加倍易用的智能拍摄功能，助你轻松创作令人艳羡的华丽影片。","899",2);
INSERT INTO shop VALUES (NULL ,"灵眸Osmo 口袋云台相机","facbf19a7c8e86e782117fee55a64f41@retina_small.png","f2ddbb40c5579391b534b87e768df5ad@origin.jpg","轻巧，便携，智能且配备独立屏幕，轻松拍摄，记录生活从此变得简单又好玩。","1999",2);
INSERT INTO shop VALUES (NULL ,"灵眸运动相机","ed213365e2222a55012758b2cbe7a7a1@retina_small.png","33ffcde840405436f5563b16425e2550@origin.jpg","灵眸运动相机拥有前后双屏，可以自由切换拍摄视角，强大的 RockSteady 增稳技术可大幅滤除画面抖动，拍摄稳定流畅的 4K 视频。","1799",2);
INSERT INTO shop VALUES (NULL ,"Osmo Mobile 灵眸手机云台3","c2124224-91e0-4227-b48b-5faf4673940c@retina_small.png","e0666e04cb976f3557e8407e7630bce8@origin.jpg","灵眸手机云台 3 采用可折叠设计，轻巧便携。三轴机械云台可实现无损防抖，丰富的智能模式，轻松应对日常记录和旅行拍摄。","549",2);
INSERT INTO shop VALUES (NULL ,"DJI Pocket 2全能手柄","540daaf7492ac55a222dd3307c0adedc@retina_small.png","0bbe78d0e8f4c685aecf4f2f5b2dfd26@origin.jpg","支持无线连接手机、无线录制声音，外接耳机或麦克风，和配件拓展。","599",2);
INSERT INTO shop VALUES (NULL ,"Osmo Pocket 加长杆","9fa353cf82535bb99011e136790181f4@retina_small.png","57898316a6869ba8d44352fdc350b346@origin.jpg","可伸缩设计，可搭载手机和三脚架等更多配件，从容应对多样拍摄需求。","399",2);
INSERT INTO shop VALUES (NULL ,"Osmo Pocket 磁吸 ND 减光镜套件","0801a82f4beeaabd2098d25ccf45784b@retina_small.png","aa0f9062-8c18-4233-9e12-1dfc0e9860c3.jpg","可还原真实色彩，满足高阶摄影用户对于精细调整快门速度的需求。","299",2);
INSERT INTO shop VALUES (NULL ,"DJI Pocket 手机夹","2bcac47b5a34c1671216068f8fc38ea1@retina_small.png","2bcac47b5a34c1671216068f8fc38ea1@retina_small.png","","299",2);
INSERT INTO shop VALUES (NULL ,"DJI RSC 2","96cddfc3dbe070d6de61ae7657d8f826@retina_small.png","0b1a1870435879217882200c1637f894@origin.jpg","DJI RSC 2 采用独特的可折叠设计，机身更加紧凑，增稳效果却依旧出众，且提供丰富的拍摄功能。它的各项改进，都将帮你点亮更多创造力，拍出拿手好戏。","2699",3);
INSERT INTO shop VALUES (NULL ,"Ronin SC 如影SC单手持微单稳定器","4abd7d0f977ad71a4e0481d044afa1c0@retina_small.png","56c6fd03d8df5937472dee0719b1d5e4@origin.jpg","Ronin SC 如影 SC 单手持微单稳定器","1299",3);
INSERT INTO shop VALUES (NULL ,"如影Ronin-S","e112765fd82f4d6fe664751c67635838@retina_small.png","e0f659ad508a80f61fc34f28847722ed@origin.jpg","专为单反和微单打造，多场景便携操作，单人也能完成专业拍摄。","3999",3);
INSERT INTO shop VALUES (NULL ,"如影 Ronin 2 专业套装","f2a415b465c12776dc0ffe8be6a446f1@retina_small.png","7f861154-fb14-4772-8258-695cfec1ed7f.jpg","动力全面提升，不仅能搭载更重的摄影机和镜头，而且能承受高速运动中的风阻与惯性，无论手持、车载或是机载，都能时刻提供稳定影像。","46999",3);
INSERT INTO shop VALUES (NULL ,"DJI R 竖拍相机固定组件","60af211e4b62348d7b4115d0f14d2769@retina_small.png","f8c5cc99fea8d4f933f6a8a2302004cf@origin.jpg","可在长时间竖拍时使用。","249",3);
INSERT INTO shop VALUES (NULL ,"DJI 多形态双手持套装","972b42ccb34c31e615d4d7eda4e907bf@retina_small.png","42e13b83f4b98eb0a3199f9822d284f3@origin.jpg","支持快速拆装，可双手握持稳定器进行拍摄，在双手持形态下无需拆卸即可快速切换低角度手提形态。","699",3);
INSERT INTO shop VALUES (NULL ,"DJI Ronin 控制手柄","6616644fc97afc172b66fb73c24424be@retina_small.png","265c5cd2b3cb9d366c7a6d3ba537d60a@origin.jpg","控制手柄上可实现休眠、录像、摇杆、跟焦等一系列操作。","1999",3);
INSERT INTO shop VALUES (NULL ,"DJI Ronin 载具扩展配件包","f844b0a16f629f6db0eda3c44672b8ee@retina_small.png","adabf32e57d41ff3be06b73fb1640d4a@origin.jpg","适配 DJI RS 2，可以实现远距离遥控和供电功能，适用于车载、滑轨、索道、摇臂等拍摄场景。","2999",3);
INSERT INTO shop VALUES (NULL ,"Phantom 4 系列智能飞行电池","8c0be49b126071cf7ef0e52367daa5b1@retina_small.png","d67aaffd-9288-4788-bce7-c1da4d604b9b.jpg","提供30分钟飞行时间","999",4);;
INSERT INTO shop VALUES (NULL ,"Phantom 4 系列降噪螺旋桨","e8fed20a-5778-460f-ade5-88ec46191eb3@retina_small.png","8594bace-54d3-484f-80be-5ec62bbb3f77.jpg","全新气动设计，出色降噪表现","59",4);
INSERT INTO shop VALUES (NULL ,"Phantom 4 系列电池管家","6381----c@retina_small.png","a682e493-9cf6-4a37-b38d-c30b46ae5b9c.jpg","三电齐充，便捷省心","499",4);
INSERT INTO shop VALUES (NULL ,"Phantom 4 系列桨叶保护罩","8ea85e1f-7aa9-4204-8a5e-f0a8aab427c8@retina_small.png","9be46374-ace7-428b-900d-30ebba270c35.jpg","Phantom 4 系列桨叶保护罩","99",4);
INSERT INTO shop VALUES (NULL ,"禅思Zenmuse X7(不含镜头)","75b3afb9-0ff1-483d-9ba7-bbca61c79e4e@retina_small.png","cbf1466f-194f-4e66-82de-03e003934251.jpg","影像新高度","16999",5);
INSERT INTO shop VALUES (NULL ,"Zenmuse X7 DL/DL-S镜头套装","e76cd84c-027e-45c4-b027-d6b2767c8b21@retina_small.png","e76cd84c-027e-45c4-b027-d6b2767c8b21@retina_small.png","","26999",5);
INSERT INTO shop VALUES (NULL ,"悟Inspire 2  TB50智能飞行电池","36cdadd0-d955-4324-804c-9b9a44cd0140@retina_small.png","58b324a9-f0e2-4f00-845c-8fb3150c7790.jpg","建议成对购买使用，最长可飞25分钟（搭载禅思X5S云台相机）","999",5);
INSERT INTO shop VALUES (NULL ,"悟Inspire 2 快拆浆","5ac2f0a0-a440-46eb-9527-862b4fe66175@retina_small.png","a826d366-16e3-4047-97a7-271fde796c4c.png","快速拆装，强劲拉力，出色动平衡。","99",5);
INSERT INTO shop VALUES (NULL ,"禅思Zenmuse X5S","4e7e8e3a-1220-4251-9a58-cd3de8fa35fe@retina_small.png","2e5fff5a-5fd1-401b-b737-51990faa7c9c.jpg","M4/3 | 5.2K | F1.7 - F16 | CinemaDNG | ProRes","12499",5);
INSERT INTO shop VALUES (NULL ,"Cendence 遥控器","ae4561fb-d7d8-4d55-ba36-87d52f1d5206@retina_small.png","77624f33-238e-4fa4-ab38-f5593b42f6e6.jpg","","6799",5);
INSERT INTO shop VALUES (NULL ,"DJI电池管理站","5178e212-3c28-4313-867f-09f049794f34@retina_small.png","412d745b-f418-4c3e-9062-50a4cd3c6e9d.jpg","一站式解决充电、储存、运输，高效地管理电池。","7699",5);
INSERT INTO shop VALUES (NULL ,"Inspire 2 手持套件","6e29b04bd83900fe66ea05f22b5268ab@retina_small.png","4e0910e9-a80b-4422-bb4e-c9bccda19d9d.jpg","“天地一体”拍摄，游刃有余。","899",5);
/* 增值服务商品 */
INSERT INTO fw_shop VALUES (NULL ,"DJI Care 随心换1年版（DJI Air 2S）","00688a0d5f16b9f800d99102ac942cbf@retina_small.png","699");
INSERT INTO fw_shop VALUES (NULL ,"DJI Care 随心换2年版（DJI Air 2S）","00688a0d5f16b9f800d99102ac942cbf@retina_small.png","1099");
INSERT INTO fw_shop VALUES (NULL ,"DJI Care 随心换1年版（DJI Mini 2S）","e20c00a20a1266cb86d91c3e8fcd7bcc@retina_small.png","299");
INSERT INTO fw_shop VALUES (NULL ,"DJI Care 随心换2年版（DJI Mini 2S）","e20c00a20a1266cb86d91c3e8fcd7bcc@retina_small.png","499");

#商品详情
INSERT INTO dj_laptop VALUES(1,1,'DJI Air 2S','低至 ¥297.86/月 x 24 期，支持花呗分期、京东白条、掌上生活分期付款','6499','DJI Air 2S','￥6499或低至 ¥297.86/月 x 24 期');
INSERT INTO dj_laptop VALUES(2,1,'DJI Air 2S 畅飞套装','低至 ¥384.94/月 x 24，支持花呗分期、京东白条、掌上生活分期付款','8399','DJI Air 2S畅飞套装','￥8399或低至 ¥384.94/月 x 24 期');
INSERT INTO dj_laptop VALUES(3,1,'DJI Air 2S 畅飞套装(DJI带屏遥控器)','低至 ¥504.11/月 x 24 期，支持花呗分期、京东白条、掌上生活分期付款','10999','DJI Air 2S 畅飞套装(DJI带屏遥控器)','￥10999或低至 ¥504.11/月 x 24 期');
INSERT INTO dj_laptop VALUES(4,2,'DJI Pocket 2 云暮白限定套装','低至 ¥137.44/月 x 24 期，支持花呗分期、京东白条、掌上生活分期付款','2999','DJI Pocket 2 云暮白限定套装','￥2999或低至 ¥137.44/月 x 24 期');
INSERT INTO dj_laptop VALUES(5,3,'DJI FPV 套装','低至 ¥366.61/月 x 24 期，支持花呗分期、京东白条、掌上生活分期付款','7999','
透影灰极光绿
3D 模型加载中

All 3D models in the page have loaded
3D 模型加载中

DJI FPV 套装','￥7999或低至 ¥366.61/月 x 24 期');


