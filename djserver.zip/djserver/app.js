// 引入express模块
const express = require("express");
// 引入路由对象
var user = require('./router/user');
// var details = require('./router/details');
// var search = require('./router/search');
// 引入body-parser模块
const bodyParser = require("body-parser");
// 创建web服务器
const app=express();
// 设置监听端口号3000
app.listen(3000);
//引入跨域管理模块
const cors = require("cors");
//配置允许跨域程序
app.use(cors({
	 origin:["http://127.0.0.1:3000","http://localhost:3000","http://localhost:8080","http://127.0.0.1:8080"]
}))
// 使用body中间件解析post请求
app.use(bodyParser.urlencoded({
    extended:false
}));
// 托管静态资源
app.use(express.static("public"));

//挂载路由
app.use('/pro',user);
// app.use('/pro',details);
// app.use('/pro',search);