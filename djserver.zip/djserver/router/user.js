//引入express模块
const express = require("express");
// 引入连接池对象
const pool = require("../pool")
// 设置路由对象
const router = express.Router();
var query=require("./query");
// 登录模块
router.post("/v1/login",(req,res)=>{
    let obj = req.body;
    let sql = "SELECT * FROM dj_user WHERE (iphone=? or email=?) AND upwd=md5(?)";
    pool.query(sql,[obj.iphone,obj.email,obj.upwd],(err,reslut)=>{
        if(err)throw(err);
        console.log(reslut)
        if(reslut.length>=1){
            res.send("1");
        }else{
            res.send("0")
        }
    })
});
// 注册模块
router.post("/v1/reg",(req,res)=>{
    let obj = req.body;
    var sql = "INSERT INTO dj_user(id,iphone,email,upwd) VALUES(NULL,?,?,md5(?))";
    if(obj.email===undefined){
        obj.email=null;
    }
    if(obj.iphone===undefined){
        obj.iphone=null;
    }
    console.log(obj)
    pool.query(sql,[obj.iphone,obj.email,obj.upwd],(err,result)=>{
        if(err)throw(err);
        console.log(result);
        if(result.affectedRows>0){
            res.send('1')
        }else{
            res.send('0')
        }
    })    
})
//根据id获取商品数据
router.get('/shop/:id',(req,res)=>{
    // console.log('mavic商品列表');
    let _id = req.params.id;
    let sql = "select * from shop where show_shopId=?";
    pool.query(sql,[_id],(err,result)=>{
        // console.log(result)
        if(err) throw err;
        res.send(result);
    });
});
// 查询要显示的类别
router.get('/show',(req,res)=>{
    let sql = "select * from show_shop";
    pool.query(sql,(err,result)=>{
        if(err)throw err;
        res.send(result);
    });
}) ;
// 服务商品
router.get('/fwshop',(req,res)=>{
    let sql = "select * from fw_shop";
    pool.query(sql,(err,result)=>{
        if(err)throw err;
        res.send(result);
    });
}) ;
// 导航类别
router.get('/nav',(req,res)=>{
    let sql = "select * from nav_type";
    pool.query(sql,(err,result)=>{
        if(err)throw err;
        res.send(result);
    });
}) ;


// 详情页功能
router.get('/details/:lid',(req,res)=>{
    let lid = req.params.lid;
    var output={};
    var sql="SELECT * FROM `dj_laptop` where lid=?";
    pool.query(sql,[lid],(err,result)=>{
        console.log(result)
        output.product=result[0];
        var fid = output.product.family_id;
        console.log(fid)
        var sql = "SELECT spec,lid,specprice FROM `dj_laptop` where family_id=?"
        pool.query(sql,[fid],(err,result)=>{
            console.log(result)
            output.specs=result;
            res.send(output)
        })
        
    });
})


// 物品搜所功能
// router.get('/search/:kw',(req,res)=>{
//     let _kw = '%' + req.params.kw + '%';
//     console.log(_kw)
//     let sql = "select * from shop_search where type or title like ? ";
//     pool.query(sql,[_kw],(err,result)=>{
//         console.log(result);
//         if(err) throw err;
//         res.send(result);
//     })
// })

//物品搜索功能
router.get("/search",(req,res)=>{
    var output={
      count:0,
      pageSize:9,
      pageCount:0,
      pno:req.query.pno||0,
      data:[]
    };
    var kw=req.query.kw||"";
    //"mac i5 128g"
    var kws=kw.split(" ");
    //[mac,i5,128g]
    kws.forEach((elem,i,arr)=>{
      arr[i]=`title like '%${elem}%'`;
    })
    /*[
      title like '%mac%',
      title like '%i5%',
      title like '%128g%'
    ]*/
    //join(" and ");
    var where=kws.join(" and ");
    //"title like '%mac%' and title like '%i5%' and title like '%128g%'"
    var sql=`select * from shop_search where ${where}`;
    query(sql,[])
    .then(result=>{
      output.count=result.length;
      output.pageCount=
        Math.ceil(output.count/output.pageSize);
      sql+=` limit ?,?`;
      return query(sql,[output.pageSize*output.pno,output.pageSize]);
    })
    .then(result=>{
      output.data=result;
      res.send(output);
    })
  })
  router.get("/shelp",(req,res)=>{
    var kw=req.query.kw;
    var kws=kw.split(" ");
    kws.forEach((elem,i,arr)=>{
      arr[i]=`title like '%${elem}%'`;
    })
    var where=kws.join(" and ");
    var sql=`select seid,title from shop_search where ${where} limit 10`;
    query(sql,[]).then(result=>{
      res.send(result);
    })
  })


module.exports = router;