//引入express模块
const express = require("express");
// 引入连接池对象
const pool = require("../pool")
// 设置路由对象
const router = express.Router();
// 搜索详情
router.get('/details/:lid',(req,res)=>{
  let lid = req.params.lid;
  var output={};
  var sql="SELECT * FROM `dj_laptop` where lid=?";
  pool.query(sql,[lid],(err,result)=>{
    console.log(result)
    output.product=result[0];
    var fid = output.product.family_id;
    console.log(fid)
    var sql = "SELECT spec,lid,specprice FROM `dj_laptop` where family_id=?"
    pool.query(sql,[fid],(err,result)=>{
      console.log(result)
      output.specs=result;
      res.send(output)
    })  
  });
})