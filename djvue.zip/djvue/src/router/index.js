import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from "../views/Login.vue"
import Product from "../views/Product.vue"
import Register from "../views/Register.vue"
import Card from "../components/Card.vue"
import CardChange from "../components/CardChange.vue"
import CardBig from "../components/CardBig.vue"
import BigCard from "../components/BigCard.vue"
import ShopCard from "../components/ShopCard.vue"
import MyHeader from "../components/MyHeader.vue"
import Search from "../views/Search.vue"
import Carousel from "../components/Carousel.vue"
import Details from "../views/Details.vue"



Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/details/:lid',
    props:true,
    component: Details
  },
  {
    path: '/carousel',
    name: 'Carousel',
    component: Carousel
  },
  {
    path: '/search/:kw',
    name: 'Search',
    component: Search,
    props:true
  },
  {
    path: '/myheader',
    name: 'MyHeader',
    component: MyHeader,
    props:true
  },
  {
    path: '/shopcard',
    name: 'ShopCard',
    component: ShopCard
  },
  {
    path: '/bigcard',
    name: 'BigCard',
    component: BigCard
  },
  {
    path: '/cardbig',
    name: 'CardBig',
    component: CardBig
  },
  {
    path: '/cardchange',
    name: 'CardChange',
    component: CardChange
  },
  {
    path: '/card',
    name: 'Card',
    component: Card
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/',
    name: 'Product',
    component: Product
  },
]

const router = new VueRouter({
  routes
})

export default router
