<template>
<div class="search">
  <my-header></my-header>
  <div class="search-middle">
    <div class="middle">
      <div class="left">
        <div style="position:sticky;top:0;">
          <!-- <div>兼容性</div>
          <div>产品类型</div>
          <div>增值服务</div> -->
        </div>
      </div>
      <div class="right">
        <div>
          <div style="margin-top:48px;font-size:26px;">"<span style="color:#44A8F2;">{{kw}}</span>"的搜索结果</div>
        </div>
        <div class="right-box">
          <div class="box" v-for="(item,i) in products" :key="i">
            <a href="" class="card-a">
              <div class="card-item">
              <img :src="`/img/${item.img}`" alt="">
              <div></div>
              <h4>{{item.type}}</h4>
            </div>
            </a>
          </div>
        </div>
        <ul>
          <li class="page-item"><a href="javascript:;" :class="{disabled:pno==0}" @click="change(-1,$event)">上一页</a></li>
          <li v-for="i of pcount" :key="i" :class="{active:i-1==pno}"><button @click="changepage(i-1)" v-text="i"></button></li>
          <li class="page-item"><a href="javascript:;" :class="{disabled:pno==pcount-1}" @click="change(+1,$event)">下一页</a></li>
        </ul>
      </div>
    </div>
  </div>
  <my-footer></my-footer>
</div>

</template>
<style scoped>
  *{
    margin: 0;
    padding: 0;
  }
  .search-middle{
    background-color: #f0f1f2;
  }
  .search-middle>.middle{
    margin: auto;
    display: flex;
    width: 1200px;
    padding-bottom: 20px;
  }
  .search-middle>.middle>.left{
    margin-top: 48px;
    margin-bottom: 78px;
    width: 288px;
    background-color: white;
    margin-right: 16px;
  }
  .search-middle>.middle>.right{
    box-sizing: border-box;
    width: 896px;
    padding-bottom: 30px;
  }
  .page-item>a{
    text-decoration: none;
  }
  .page-item>.disabled{
    display: none;
  }
  .right>ul{
    text-align: center;
    list-style: none;
  }
  .right>ul>li{
    display: inline-block;
    margin: 0 2px;
    border: 1px solid transparent;
    border-radius: 3px;
    box-sizing: border-box;
    padding: 5px 10px;
  }
  .right>ul>li>button{
    border: 0;
    background-color: transparent;
    outline: none;
  }
  .right .active{
    background-color: #1890ff;
    border-color: #1890ff
  }
  .right-box{
    display: flex;
    flex-wrap: wrap;
    position: relative;
  }
  .right-box>.box{
    width: 282px;
    height: 420px;
    background-color:white;
    box-sizing: border-box;
    margin-top: 16px;
    margin-left: 10px;
  }
  .box>.card-a{
    text-decoration: none;
  }
  .box>:hover{
    box-shadow: 0 15px 10px -15px #333;
  }
  .box>.card-a>.card-item{
    box-sizing: border-box;
    width: 288px;
    height: 420px;
  }
  .box>.card-a>.card-item img{
    padding: 24px 16px 8px;
    width: 288px;
    height: 288px;
  }
  .box>.card-a>.card-item div{
    /* width: 100%; */
    height: 24px;
  }
  .box>.card-a>.card-item h4{
    padding: 0 24px;
    font-size: 18px;
    color: #3b3e40;
  }
</style>
<script>
export default {
  data(){
    return{
      pno:1,
      pcount:0,
      products:[]
    }
  },
  props:["kw"],
  methods:{
    change(n,e){
      if(e.target.className.indexOf("disabled")==-1){
        this.changepage(parseInt(this.pno)+parseInt(n))
      }
    },
    changepage(i){
      console.log(i)
      this.load(i)
    },
    load(pno=0){//封装axios请求
      this.axios.get('/search',{params:{kw:this.kw,pno}}).then(result=>{
        console.log(result.data);
        this.pno = result.data.pno;
        this.pcount = result.data.pageCount
        this.products = result.data.data;
      })
    }
  },
  created(){
    this.load()
  },
  watch:{
    kw(){
      this.load()
    }
  }
}
</script>