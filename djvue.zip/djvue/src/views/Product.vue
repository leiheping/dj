<template>
  <div class="product">
    <my-header></my-header>
    <section style="margin-top:0px;">
      <carousel></carousel>
    </section>
    <div class="middle" style="margin-top:60px;">
      <div class="middle-card-big">
        <div>
          <card-big></card-big>
          <card-big2></card-big2>
          <card-big3></card-big3>
        </div> 
      </div>
      <div class="middle-big-card">
        <div>
          <big-card></big-card>
        </div>
      </div>
      <shop-card></shop-card>
      <div class="middle-card">
        <div class="middle-card-fw">增值服务
          <div class="middle-card-more"><a href="">更多></a></div>
        </div>
        <div class="nav-item">
          <my-card></my-card>
        </div>
      </div>
    </div>
    <my-footer></my-footer>
  </div>
</template>
<style scoped>

  .product{
    background-color: #f0f1f2;
  }
  .product>.middle>.middle-card{
    margin: 48px 0;
  }
  .product> .middle .nav-item{
    width: 1200px;
    display: flex;
    justify-content: space-between;
    margin: 0 auto;
  }
  .product>.middle>.middle-card>.middle-card-fw{
    width: 1200px;
    height: 32px;
    margin: 0 auto;
    margin-bottom: 16px;
    line-height: 32px;
    font-size: 32px;
    text-align: justify;
    position: relative;
  }
  .product>.middle>.middle-card .middle-card-more a{
    position: absolute;
    right: 0;
    font-size: 16px;
    top: 0;
    color: #3b3e40;
    margin: 0 0 0 16px;
    text-decoration: none;
  }
  .product>.middle>.middle-card .middle-card-more:hover a{
    color: #1897f2;
  }
  .middle-card-big{
    width: 1200px;
    margin: 0 auto;
  }
  .middle-card-big div{
    display: flex;
    justify-content: space-between;
    row-gap: row;
    margin: 0 0 16px;
  }
  .middle-big-card{
    width: 1200px;
    margin: 0 auto;
  }
  .middle-big-card div{
    display: flex;
    justify-content: space-between;
    row-gap: row;
    margin: 0 0 16px;
  }
  .middle-shop-card{
    width: 1200px;
    margin: 0 auto;
  }
  .middle-shop-card div{
    display: flex;
    justify-content: space-between;
    row-gap: row;
  }
</style>
<script>
import CardBig from '../components/CardBig.vue'
import ShopCard from '../components/ShopCard.vue'
import Carouse from '../components/Carousel.vue'
export default {
  components: { CardBig, ShopCard,Carouse },
  data(){
    ShopCard
    return{
    }
  }
}
</script>