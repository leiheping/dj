<template>
  <div class="login">
        <div class="reg">
            <div class="reg-log"><img src="../../public/img/log.svg" alt=""></div>
            <div class="reg-carousel">
                <div id="adv" class="carousel" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active"><img src="../../public/img/1.jpg" alt="" ></div>
                        <div class="carousel-item"><img src="../../public/img/2.jpg" alt="" ></div>
                        <div class="carousel-item"><img src="../../public/img/3.jpg" alt="" ></div>
                        <a href="#adv" class="carousel-control-prev
                        " data-slide="prev"><span class="carousel-control-prev-icon"></span></a>
                        <a href="#adv" class="carousel-control-next" data-slide="next"><span class="carousel-control-next-icon"></span></a>
                    </div>
                    <!-- <a href="#adv" class="carousel-control-prev
                    " data-slide="prev"><span class="carousel-control-prev-icon"></span></a>
                    <a href="#adv" class="carousel-control-next" data-slide="next"><span class="carousel-control-next-icon"></span></a> -->
                    <ul class="carousel-indicators xz-ind">
                        <li class="active" data-slide-to="0" data-target="#adv"></li>
                        <li class="" data-slide-to="1" data-target="#adv"></li>
                        <li class="" data-slide-to="2" data-target="#adv"></li>
                    </ul>
                </div>
            </div>
            <div class="reg-right">
                <div class="reg-from">
                    <div>
                        <div class="text-center">
                            <div class="title">登录</div>
                        </div>
                        <div class="input">
                            <input type="text" id="uname" placeholder="邮箱/手机*" v-model="uname"><table style="color:red">{{str}}</table>
                        </div>
                        <div class="password clearfix">
                            <input type="text" id="upwd" placeholder="密码*" class="float-left" v-model="upwd">
                            <div class="float-right"><a href="" class="text-center psd">忘记密码?</a></div>
                        </div>
                        <div class="button">
                            <button @click="login">登录</button>
                        </div>
                        <div class="phone- clearfix">
                            <a href="/#/login" class="float-left">手机短信登录/注册</a>
                            <a href="/#/register" class="float-right">注册Dji账号</a>
                        </div>
                        <div class="third-wx">
                            <div class="line text-center">
                                <div class="third">或使用第三方账号登录</div>
                            </div>
                            <button type="button" class="btn">微信</button>
                        </div>
                        <div class="login-agree text-center">
                            <span>
                                若继续,则表示同意<a href="">隐式政策</a>和<a href="">使用条款</a>DJI 会收集您的第三方登录信息进行账号注册或登录。
                            </span>
                        </div>
                    </div>
                    <div class="login-question">
                        <div>登录遇到问题？</div>
                        <div>
                            <a href="" class="faq-left">联系客服</a>
                            <a href="" class="faq-right">常见问题</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer">
            <div>
                <span>Copyright © 2021 DJI All Rights Reserved.&nbsp;<a href="">隐私政策</a>&nbsp;<a href="">使用条款</a>&nbsp;<a href="">网站地图</a></span>
            </div>
            <div>
                <span>如果您有任何关于DJI账户的问题，&nbsp;<a href="">点击此处</a></span>
            </div>
            <div>
                <span>粤ICP备12022215号-11</span>
            </div>
        </div>
  </div>
</template>
<script>
export default {
    data(){
        return{
            str:"",
            uname:"",
            upwd:""
        }
    },
    methods:{
        login(){
            if(this.uname.length==11){
                this.axios.post('/v1/login',`iphone=${this.uname}&upwd=${this.upwd}`).then(result=>{
                    if(result.data>0){
                        this.$router.push('/')
                    }else{
                        this.str = '账号或密码错误'
                    }
                });
            }else{
                this.axios.post('/v1/login',`email=${this.uname}&upwd=${this.upwd}`).then(result=>{
                    if(result.data>0){
                        this.$router.push('/')
                    }else{
                        this.str = '账号或密码错误'
                    }
                });
            }

        }
    }
}
</script>
<style scoped>
    .login{
        width: 100%;
        height: 100%;
        background-color: #eee;
        position:absolute;
    }
    .xz-ind>li{
        width: 10px;
        height: 10px;
        border-radius: 50%;
    }
    .adv{
        width: 500px;
        height: 708px;
    }
    .carousel-item>img{
        height: 708px ;
        width: 500px ;
    }
    .reg{
        width: 1000px;
        height: 708px;
        margin: 80px auto;
    }
    .reg-carousel{
        width: 500px;
        height: 708px;
        float: left;
    }
    .reg-right{
        width: 500px;
        height: 708px;
        float: right;
        padding: 60px 0;
    }
    .reg-log{
        width: 132px;
        height: 110px;
        position: absolute;
        z-index: 2;
    }
    .reg-log>img{
        padding: 40px;
        color: white;
    }
    .carousel-title{
        position: absolute;
        z-index: 2;
    }
    .reg-right{
        background-color: white;
    }
    .reg-from{
        width: 300px;
        height: 588px;
        margin: 0 auto;
    }
    .reg-from .title{
        color: #3b3e40;
        font-weight: 500;
        font-size: 30px;
    }
    .reg-from .input>input{
        width: 300px;
        height: 46px;
        margin-top: 22px;
    }
    .reg-from .password{
        border: 1px solid #979797;
        width: 300px;
        height: 48px;
        margin-top: 20px;
    }
    .reg-from .password>input{
        width: 150px;
        height: 46px;
        border: none;
        outline: none;
    }
    .reg-from .password .psd{
        line-height: 48px;
        margin-right: 10px;
        font-size: 12px;
    }
    .reg-from .button{
        margin-top: 20px;
    }
    .reg-from .button button{
        width: 300px;
        height: 46px;
        background-color: #44a8f2;
        color: white;
        border: 1px solid #44a8f2;
    }
    .reg-from .phone- {
        margin-top: 20px;
    }
    .reg-from .line{
        margin-top: 30px;
    }
    .line .third{
        color: #707473;
        padding: 6px 8px;
        display: inline-block;
        line-height: 44px;
    }
    .third-wx button{
        margin-top: 10px;
        width: 300px;
        height: 48px;
        padding: 1px 6px;
        background-color: #47b247;
    }
    .login-agree >span{
        font-size: 12px;
        color: #707473;
        margin-top: 10px;
    }
    .login-agree >span a{
        color: #333;
    }
    .login-question{
        margin-top: 64px;
        text-align: center;
    }
    .login-question>:first-child{
        color: rgba(0,0,0,.85);
        font-size: 14px;
    }
    .login-question .faq-left{
        font-size: 14px;
        padding-right:8px;
        color: #44a8f2;
    }
    .login-question .faq-right{
        font-size: 14px;
        padding-left:8px;
        color: #44a8f2;
    }
    .footer {
        text-align: center;
        font-size: 12px;
        color: #979797;
    }
    .footer a{
        color: #979797;

    }
</style>