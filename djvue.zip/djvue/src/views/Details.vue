<template>
  <div class="detail">
    <my-header></my-header>
    <div class="detail-middle">
      <div class="detail-nav">
        <ul>
          <li><a href="">商城 </a></li>
          <li><a href="">御 Mavic 系列 </a></li>
          <li><a href="">{{product.type}} </a></li>
          <li>{{product.type}}</li>
        </ul>
      </div>
    </div>
    <div>
      <div class="detail-main">
        <div class="detail-section">
          <div class="details-carousel" style="position: relative">
            <div class="detail-carousel" style="position: sticky; top: 0">
              <div id="adv" class="carousel" data-ride="carousel">
                <div class="carousel-inner">
                  <div class="carousel-item active" style="width: 656px">
                    <img
                      src="../../public/img/f66aa805ae7be8c98390cbfde3f42256@ultra.jpg"
                      alt=""
                      style="width: 100%"
                    />
                  </div>
                  <div class="carousel-item" style="width: 656px">
                    <img
                      src="../../public/img/88ab281db0330941a1b0dfa1d9a60ed0@ultra.jpg"
                      alt=""
                      style="width: 100%"
                    />
                  </div>
                  <div class="carousel-item" style="width: 656px">
                    <img
                      src="../../public/img/96a64dabed72cea784a52e4a31a9ce22@ultra.jpg"
                      alt=""
                      style="width: 100%"
                    />
                  </div>
                  <div class="carousel-item" style="width: 656px">
                    <img
                      src="../../public/img/a4eb1ddaf35330021088d17083746baf@ultra.jpg"
                      alt=""
                      style="width: 100%"
                    />
                  </div>
                  <div class="carousel-item" style="width: 656px">
                    <img
                      src="../../public/img/d475a3c18efe09bc305808044b513690@ultra.jpg"
                      alt=""
                      style="width: 100%"
                    />
                  </div>
                  <div class="carousel-item" style="width: 656px">
                    <img
                      src="../../public/img/91cfe8d96d09ef6fbfb611aa5e15c100@ultra.jpg"
                      alt=""
                      style="width: 100%"
                    />
                  </div>
                  <a
                    href="#adv"
                    class="carousel-control-prev"
                    data-slide="prev"
                  >
                    <div class="prev-icon">
                      <span class="carousel-control-prev-icon"></span>
                    </div>
                  </a>
                  <a
                    href="#adv"
                    class="carousel-control-next"
                    data-slide="next"
                  >
                    <div class="prev-icon">
                      <span class="carousel-control-next-icon"></span>
                    </div>
                  </a>
                </div>
                <ul class="carousel-indicators xz-ind">
                  <li class="active" data-slide-to="0" data-target="#adv"></li>
                  <li class="" data-slide-to="1" data-target="#adv"></li>
                  <li class="" data-slide-to="2" data-target="#adv"></li>
                  <li class="" data-slide-to="3" data-target="#adv"></li>
                  <li class="" data-slide-to="4" data-target="#adv"></li>
                  <li class="" data-slide-to="5" data-target="#adv"></li>
                </ul>
              </div>
            </div>
          </div>
          <div class="details-title">
            <div class="title">
              <h1>{{product.type}}</h1>
              <div style="margin-top: 16px">
                <span style="font-size: 24px">￥{{product.price}}</span>
              </div>
              <div style="margin-top: 6px">
                <span style="display: block; font-size: 14px"
                  >{{product.title}}</span
                >
              </div>
              <div style="margin-top: 16px; line-height: 20px">
                <ul
                  style="
                    font-size: 14px;
                    text-align: left;
                    list-style-position: inside;
                  "
                >
                  <li>一英寸影像传感器</li>
                  <li>5.4K 超高清视频</li>
                  <li>大师镜头</li>
                  <li>12 公里 1080p 图传</li>
                  <li>四向环境感知</li>
                </ul>
              </div>
              <div style="margin-top: 8px"><a href="">产品概念</a></div>
            </div>
            <div class="pack">
              <div>
                <h3 style="font-size: 20px">选择套餐</h3>
                <div><a href="">包装清单对比</a></div>
                <ul class="pack-ul">
                  <li v-for="sp of specs" :key="sp.lid" :data-i="sp.lid" @click="changen(sp.lid)">
                    <router-link :to="`${sp.lid}`" style="list-style:none;text-decoration:none;">
                      <label for="" class="checkable">
                        <div
                          style="
                            padding: 23px;
                            border-radius: 8px;
                            border: 1px solid #f0f1f2;
                          "
                          :class="{border:sp.lid==n}">
                          <div>{{sp.spec}}</div>
                          <div>{{sp.specprice}}</div>
                        </div>
                      </label>
                    </router-link>
                  </li>
                </ul>
              </div>
            </div>
            <div class="parts"></div>
            <div class="serve">
              <h3>热销配件</h3>
              <ul>
                <li style="list-style: none; border:1px solid #36d;border-radius:8px;">
                  <label
                    for="" style="position: relative;"
                    ><input
                      type="checkbox" style="
                        box-sizing: border-box;
                        padding: 20px;
                        border: 1px solid #36d;
                        position: absolute;
                        top:25%;
                        left:10%
                      " />
                    <div>
                      <div style="display:flex;padding:24px;">
                        <div style="padding:24px;">
                          <div
                            class="input style__input___2DBt2"
                            tabindex="0"
                          ></div>
                        </div>
                        <div>
                          <img style="width: 64px;height: 64px;"
                            src="../../public/img/de8fe5d3d033418a64e75d49a9b11412@small.png"
                            alt="Cover"
                          />
                        </div>
                        <div>
                          <div>
                            <div>
                              <header>
                                <div
                                  role="presentation"
                                  class="style__product-title-v2___2t-4Z"
                                >
                                  闪迪 microSD 卡 128GB
                                </div>
                              </header>
                            </div>
                            <div class="style__money-wrapper___13jzE">
                              <div
                                style="font-size: 16px; display: inline-block"
                              >
                                <div>
                                  <span>¥159</span
                                  >
                                </div>
                              </div>
                            </div>
                            <div style="height: 32px"></div>
                            <p>
                              支持长时间录制 4K 视频以及高速传输。
                            </p>
                            <div>
                              <span>商品明细</span><i
                                class="_1pvYF style__plus___1if87 _3c0Qz"
                                style="font-family: quark"
                              ></i>
                            </div>
                          </div>
                        </div>
                      </div></div
                  ></label>
                </li>
                <li style="list-style: none; border:1px solid #36d;border-radius:8px;margin-top:8px;">
                  <label
                    for="" style="position: relative;"
                    ><input
                      type="checkbox" style="
                        box-sizing: border-box;
                        padding: 20px;
                        border: 1px solid #36d;
                        position: absolute;
                        top:25%;
                        left:10%
                      " />
                    <div>
                      <div style="display:flex;padding:24px;">
                        <div style="padding:24px;">
                          <div
                            class="input style__input___2DBt2"
                            tabindex="0"
                          ></div>
                        </div>
                        <div>
                          <img style="width: 64px;height: 64px;"
                            src="../../public/img/e7c631ab75d4be3ff076c12a68736f45@small.png"
                            alt="Cover"
                          />
                        </div>
                        <div>
                          <div>
                            <div>
                              <header>
                                <div
                                  role="presentation"
                                  class="style__product-title-v2___2t-4Z"
                                >
                                  DJI Air 2S ND 镜套装<br>
                                  (ND64/128/256/515)
                                </div>
                              </header>
                            </div>
                            <div class="style__money-wrapper___13jzE">
                              <div
                                style="font-size: 16px; display: inline-block"
                              >
                                <div>
                                  <span>¥549</span
                                  >
                                </div>
                              </div>
                            </div>
                            <div style="height: 32px"></div>
                            <p>
                              提供更多创作可能的ND镜套装。
                            </p>
                            <div>
                              <span>商品明细</span><i
                                class="_1pvYF style__plus___1if87 _3c0Qz"
                                style="font-family: quark"
                              ></i>
                            </div>
                          </div>
                        </div>
                      </div></div
                  ></label>
                </li>
                <li style="list-style: none; border:1px solid #36d;border-radius:8px;margin-top:8px;">
                  <label
                    for="" style="position: relative;"
                    ><input
                      type="checkbox" style="
                        box-sizing: border-box;
                        padding: 20px;
                        border: 1px solid #36d;
                        position: absolute;
                        top:25%;
                        left:10%
                      " />
                    <div>
                      <div style="display:flex;padding:24px;">
                        <div style="padding:24px;">
                          <div
                            class="input style__input___2DBt2"
                            tabindex="0"
                          ></div>
                        </div>
                        <div>
                          <img style="width: 64px;height: 64px;"
                            src="../../public/img/df222c337bedbcd8f3a4dfd957c17177@small.png"
                            alt="Cover"
                          />
                        </div>
                        <div>
                          <div>
                            <div>
                              <header>
                                <div
                                  role="presentation"
                                  class="style__product-title-v2___2t-4Z"
                                >
                                  御 Mavic Air 2 车载充电器
                                </div>
                              </header>
                            </div>
                            <div class="style__money-wrapper___13jzE">
                              <div
                                style="font-size: 16px; display: inline-block"
                              >
                                <div>
                                  <span>¥299</span
                                  >
                                </div>
                              </div>
                            </div>
                            <div style="height: 32px"></div>
                            <p>
                              自驾旅途必备配件
                            </p>
                            <div>
                              <span>商品明细</span><i
                                class="_1pvYF style__plus___1if87 _3c0Qz"
                                style="font-family: quark"
                              ></i>
                            </div>
                          </div>
                        </div>
                      </div></div
                  ></label>
                </li>
                <li style="list-style: none; border:1px solid #36d;border-radius:8px;margin-top:8px;">
                  <label
                    for="" style="position: relative;"
                    ><input
                      type="checkbox" style="
                        box-sizing: border-box;
                        padding: 20px;
                        border: 1px solid #36d;
                        position: absolute;
                        top:25%;
                        left:10%
                      " />
                    <div>
                      <div style="display:flex;padding:24px;">
                        <div style="padding:24px;">
                          <div
                            class="input style__input___2DBt2"
                            tabindex="0"
                          ></div>
                        </div>
                        <div>
                          <img style="width: 64px;height: 64px;"
                            src="../../public/img/e91f272aefe494d79c288f214d4815cc@small.png"
                            alt="Cover"
                          />
                        </div>
                        <div>
                          <div>
                            <div>
                              <header>
                                <div
                                  role="presentation"
                                  class="style__product-title-v2___2t-4Z"
                                >
                                  御 Mavic Air 2 浆叶保护罩
                                </div>
                              </header>
                            </div>
                            <div class="style__money-wrapper___13jzE">
                              <div
                                style="font-size: 16px; display: inline-block"
                              >
                                <div>
                                  <span>¥99</span
                                  >
                                </div>
                              </div>
                            </div>
                            <div style="height: 32px"></div>
                            <p>
                              轻盈守护，安心飞行
                            </p>
                            <div>
                              <span>商品明细</span><i
                                class="_1pvYF style__plus___1if87 _3c0Qz"
                                style="font-family: quark"
                              ></i>
                            </div>
                          </div>
                        </div>
                      </div></div
                  ></label>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="detail-kb"></div>
        <div>
          <h3
            style="
              font-size: 32px;
              font-weight: 600;
              line-height: 40px;
              text-align: center;
            "
          >
            包装清单
          </h3>
          <div style="margin-top: 16px">
            <ul class="select-ul-list">
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/67b7a061547cd8d17574f7a6211ed5ab@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>飞行器</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/3f266c4d664ebbd38a5149bb187b6f09@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>DJI RC-N1 遥控器</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/59c86a26dd5986243f065ab4238b0e39@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>智能飞行电池</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/9174c731a1e00d0cd2c36af8396a3151@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>电池充电器</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/cd40d13cdfe04733f2379f0f8b86796f@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>AC 电源线</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/182a80259383e401b50e8419b5309e95@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>降噪螺旋桨（对）</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/a69e371fdc54cdc5550ba9c851dc641d@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>云台保护罩</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/42895407d9656e95ecb4107b2ba06a44@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>数据线-USB 3.0 Type-C</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/f2e22e7af2e666b3d41bac20d031c64c@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>遥控器转接线（USB Type-C 接头）</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/fa8cd6e19b0c29eda1ca8d440714548c@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>遥控器转接线（Lightning 接头）</p>
                  <p>x1</p>
                </div>
              </li>
              <li>
                <div style="background-color: #f7f9fa">
                  <img
                    src="../../public/img/fa8cd6e19b0c29eda1ca8d440714548c@retina_small.png"
                    alt=""
                  />
                </div>
                <div>
                  <p>遥控器转接线（标准 Micro USB 接头）</p>
                  <p>x1</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="detail-big-carousel">
          <h3>万班精彩，你也能拍！</h3>
          <div class="reg-carousel">
            <div id="adv" class="carousel" data-ride="carousel">
              <div class="carousel-inner">
                <div
                  class="carousel-item active"
                  style="width: 1200px; height: 720px"
                >
                  <img
                    src="../../public/img/4374aac0fed6fb851e887037c9ea689e.jpg"
                    alt=""
                  />
                </div>
                <div class="carousel-item" style="width: 1200px; height: 720px">
                  <img
                    src="../../public/img/09d334e61d5105f50ee5803feaccd165.jpg"
                    alt=""
                  />
                </div>
                <div class="carousel-item" style="width: 1200px; height: 720px">
                  <img
                    src="../../public/img/b82d59cf2c902c893912294b3204e6d5.jpg"
                    alt=""
                  />
                </div>
                <a href="#adv" class="carousel-control-prev" data-slide="prev"
                  ><span class="carousel-control-prev-icon"></span
                ></a>
                <a href="#adv" class="carousel-control-next" data-slide="next"
                  ><span class="carousel-control-next-icon"></span
                ></a>
              </div>
              <!-- <a href="#adv" class="carousel-control-prev
              " data-slide="prev"><span class="carousel-control-prev-icon"></span></a>
              <a href="#adv" class="carousel-control-next" data-slide="next"><span class="carousel-control-next-icon"></span></a> -->
              <ul class="carousel-indicators xz-ind">
                <li class="active" data-slide-to="0" data-target="#adv"></li>
                <li class="" data-slide-to="1" data-target="#adv"></li>
                <li class="" data-slide-to="2" data-target="#adv"></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <my-footer></my-footer>
  </div>
</template>
<script>
export default {
  watch:{
    lid(){
      this.axios.get(`/details/${this.lid}`).then(result=>{
        console.log(result.data)
        this.product=result.data.product;
        this.specs=result.data.specs;
        console.log(this.product,this.specs)
      })
    }
  },
  data(){
    return{
      product:{price:0},
      specs:[],
      n:1
    }
  },
  methods:{
    changen(n){
      this.n=n;
    }
  },
  props:["lid"],
  mounted(){
    // console.log(this.lid)
    this.axios.get(`/details/${this.lid}`).then(result=>{
      // console.log(result.data)
      this.product=result.data.product;
      this.specs=result.data.specs;
      // console.log(this.product,this.specs)
    })
  }
}
</script>
<style>
* {
  margin: 0;
  padding: 0;
}
.pack {
  padding: 48px 0 0;
}
.style-wrapper {
  text-align: left;
  padding: 24px;
  border-radius: 8px;
  overflow: hidden;
}
.prev-icon {
  width: 50px;
  height: 50px;
  background-color: #333;
  border-radius: 50%;
}
.prev-icon > span {
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -10px;
  margin-left: -10px;
}
.pack .pack-ul .border{
  background-color: red;
}
.detail-big-carousel {
  margin: 96px 0;
}
.detail-big-carousel > h3 {
  font-size: 32px;
  text-align: center;
}
.serve {
  padding-top: 48px;
}
.serve > h3 {
  font-size: 20px;
}
.detail-big-img {
  margin: 96px 0;
}
.detail-big-img > h3 {
  font-size: 32px;
  text-align: center;
}
.select-ul-list {
  display: flex;
  flex-wrap: wrap;
  margin-left: -8px;
  margin-right: -8px;
  list-style: none;
  flex: 0 0 16.66666%;
}
.select-ul-list > li {
  margin: 16px 0 0;
  padding: 0 8px;
  width: 202px;
  height: 238px;
}
.select-ul-list > li img {
  width: 186px;
  height: 186px;
}
.pack ul {
  font-size: 14px;
  text-align: left;
  margin-top: 16px;
  list-style: none;
}
.pack ul .checkable {
  display: block;
  font-size: 16px;
  color: #333;
}
.title {
  position: relative;
  color: #000000d9;
}
.title > h1 {
  font-size: 32px;
  line-height: 36px;
  margin: 0;
  color: #333;
}
.detail-section {
  display: flex;
  justify-content: space-between;
  height: 1748px;
}
.detail-section > .details-carousel {
  width: 656px;
}
.detail-section > .details-title {
  width: 500px;
}
.detail-main {
  width: 1200px;
  margin: 0 auto;
}
.detail-main > .detail-kb {
  height: 128px;
  border-top: 1px solid #f0f1f2;
  padding-top: 63px;
  top: 50%;
}
.detail-middle > .detail-nav {
  width: 1200px;
  position: relative;
  min-width: 1200px;
  padding: 20px 0;
  box-sizing: border-box;
  margin: auto;
}
.detail-middle > .detail-nav > ul {
  display: flex;
  list-style: none;
  margin: 0;
}
.detail-middle > .detail-nav > ul li::before {
  content: "/\A0";
  margin: 0 5px;
  color: #ccc;
}
.detail-middle > .detail-nav > ul :first-child::before {
  content: "";
}
.detail-middle > .detail-nav > ul li {
  line-height: 17px;
  font-size: 12px;
}
.detail-middle > .detail-nav > ul a {
  font-size: 12px;
  color: #707473;
}
.pruduct-footer-menu-item {
  display: none !important;
}
</style>