<template>
  <div class="register">
        <div class="reg">
            <div class="reg-log"><img src="../../public/img/log.svg" alt=""></div>
            <div class="reg-carousel">
                <div id="adv" class="carousel" data-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active"><img src="../../public/img/1.jpg" alt="" ></div>
                        <div class="carousel-item"><img src="../../public/img/2.jpg" alt="" ></div>
                        <div class="carousel-item"><img src="../../public/img/3.jpg" alt="" ></div>
                        <a href="#adv" class="carousel-control-prev
                        " data-slide="prev"><span class="carousel-control-prev-icon"></span></a>
                        <a href="#adv" class="carousel-control-next" data-slide="next"><span class="carousel-control-next-icon"></span></a>
                    </div>
                    <!-- <a href="#adv" class="carousel-control-prev
                    " data-slide="prev"><span class="carousel-control-prev-icon"></span></a>
                    <a href="#adv" class="carousel-control-next" data-slide="next"><span class="carousel-control-next-icon"></span></a> -->
                    <ul class="carousel-indicators xz-ind">
                        <li class="active" data-slide-to="0" data-target="#adv"></li>
                        <li class="" data-slide-to="1" data-target="#adv"></li>
                        <li class="" data-slide-to="2" data-target="#adv"></li>
                    </ul>
                </div>
            </div>
            <div class="reg-right">
                <div class="reg-right-logo"><img src="../../public/img/log.svg" alt=""></div>
                <div class="reg-from">
                    <div>
                        <div class="text-center">
                            <div class="title">注册</div>
                        </div>
                        <div class="select">
                            <div class="phone" :class="(active=='true')?'active-phone':''" @click="phone">
                                <a>手机注册</a>
                            </div>
                            <div class="email" :class="(active=='false')?'active-email':''" @click="email">
                                <a>邮箱注册</a>
                            </div>
                        </div>
                        <div class="select-phone" v-if="select">
                            <div class="select-phone-button">
                                <button>+86</button>
                                <input type="text" placeholder="请输入手机号">
                            </div>
                            <div>
                                <my-hd></my-hd>
                            </div>
                            <div class="d-input">
                                <div class="d-input-button">
                                    <input type="text" placeholder="短信验证码">
                                    <button>发送验证码</button>
                                </div>
                            </div>
                            <div class="register-button">
                                <button>下一步</button>
                                <a href="/#/login">立即登录</a>
                            </div>
                            <div class="register-question-div">
                                <div>注册遇到问题？</div>
                                <div>
                                    <a href="" class="faq-left">联系客服</a>
                                    <a href="" class="faq-right">常见问题</a>
                                </div>
                            </div>
                        </div>
                        <div class="select-email" v-else>
                            <div class="input">
                                <input type="text" id="email" placeholder="邮箱*" class="w-100" v-model="emailres"><table>{{str1}}</table>
                            </div>
                            <div class="password clearfix">
                                <input type="text" id="upwd" placeholder="密码*" class="float-left" v-model="eupwd1">
                                <table style="font-size: 14px;float: left;color: red;line-height: 46px;">{{str2}}</table>
                            </div>
                            <div class="password clearfix">
                                <input type="text" id="upwd" placeholder="再次输入密码*" class="float-left" v-model="eupwd2">
                            </div>
                            <my-hd></my-hd>
                            <div class="row-tip">
                                <label for="">
                                    <input type="checkbox" name="input">
                                    <span>
                                        获取大疆最新产品、服务、软件升级等信息
                                    </span>
                                </label>
                                <label for="">
                                    <input type="checkbox" name="input" @click="check">
                                    <span>同意并愿意遵守大疆创新<a href="">隐私政策</a>和<a href="">使用条框</a></span>
                                </label>
                            </div>                        
                            <div class="button">
                                <button :class="(dis)?'btn-btn':''" @click="res">提交</button>
                                <div><a href="/#/login">立即登录</a></div>
                            </div>
                            <div class="register-question">
                                <div>注册遇到问题？</div>
                                <div>
                                    <a href="" class="faq-left">联系客服</a>
                                    <a href="" class="faq-right">常见问题</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="footer">
            <div>
                <span>Copyright © 2021 DJI All Rights Reserved.&nbsp;<a href="">隐私政策</a>&nbsp;<a href="">使用条款</a>&nbsp;<a href="">网站地图</a></span>
            </div>
            <div>
                <span>如果您有任何关于DJI账户的问题，&nbsp;<a href="">点击此处</a></span>
            </div>
            <div>
                <span>粤ICP备12022215号-11</span>
            </div>
        </div>
  </div>
</template>
<style scoped>
    .register{
        width: 100%;
        height: 100%;
        background-color: #eee;
        position:absolute;
    }
    .xz-ind>li{
        width: 10px;
        height: 10px;
        border-radius: 50%;
    }
    .adv{
        width: 500px;
        height: 708px;
    }
    .carousel-item>img{
        height: 708px ;
        width: 500px ;
    }
    .reg{
        width: 1000px;
        height: 708px;
        margin: 80px auto;
    }
    .reg-carousel{
        width: 500px;
        height: 708px;
        float: left;
    }
    .reg-right{
        width: 500px;
        height: 708px;
        float: right;
        padding: 60px 0;
    }
    .reg-log{
        width: 132px;
        height: 110px;
        position: absolute;
        z-index: 2;
    }
    .reg-log>img{
        padding: 40px;
        color: white;
    }
    .carousel-title{
        position: absolute;
        z-index: 2;
    }
    .reg-right{
        background-color: white;
    }
    .reg-from{
        width: 300px;
        height: 588px;
        margin: 0 auto;
        margin-top: 15px;
    }
    .reg-from .title{
        color: #3b3e40;
        font-weight: 500;
        font-size: 30px;
    }
    .reg-from .input>input{
        width: 300px;
        height: 46px;
        margin-top: 22px;
    }
    .reg-from .password{
        border: 1px solid #979797;
        width: 300px;
        height: 48px;
        margin-top: 20px;
        margin-bottom: 20px;
    }
    .reg-from .password>input{
        width: 150px;
        height: 46px;
        border: none;
        outline: none;
    }
    .reg-from .password .psd{
        line-height: 48px;
        margin-right: 10px;
        font-size: 12px;
    }
    .button{
        margin: 0;
    }
    .reg-from .button button{
        width: 300px;
        height: 46px;
        background-color: #44a8f2;
        color: white;
        border: 1px solid #44a8f2;
        opacity: 0.5;
        cursor:not-allowed;
        outline: none;
    }
    .reg-from .button .btn-btn{
        width: 300px;
        height: 46px;
        background-color: #44a8f2;
        color: white;
        border: 1px solid #44a8f2;
        opacity: 1;
        cursor: pointer;
    }
    .button div{
        font-size: 14px;
        padding: 10px 0 30px 0;
    }
    .reg-from .phone- {
        margin-top: 20px;
    }
    .reg-from .line{
        margin-top: 30px;
    }
    .line .third{
        color: #707473;
        padding: 6px 8px;
        display: inline-block;
        line-height: 44px;
    }
    .third-wx button{
        margin-top: 10px;
        width: 300px;
        height: 48px;
        padding: 1px 6px;
        background-color: #47b247;
    }
    .register-question{
        text-align: center;
    }
    .register-question>:first-child{
        color: rgba(0,0,0,.85);
        font-size: 14px;
    }
    .register-question .faq-left{
        font-size: 14px;
        padding-right:8px;
        color: #44a8f2;
    }
    .register-question .faq-right{
        font-size: 14px;
        padding-left:8px;
        color: #44a8f2;
    }
    .footer {
        text-align: center;
        font-size: 12px;
        color: #979797;
    }
    .footer a{
        color: #979797;

    }
    .select{ 
        display: flex;
        border-bottom: 1px solid #eee;
        cursor: pointer;
    }
    .select>.phone{
        width: 150px;
        height: 55px;
        line-height: 55px;
    }
    .select>.email{
        width: 150px;
        height: 55px;
        line-height: 55px;
    }
    .select>.active-phone{
        color: #44a8f2;
        border-bottom: 1px solid #44a8f2;
    }
    .select>.active-email{
        color: #44a8f2;
        border-bottom: 1px solid #44a8f2;
    }
    .row-tip{
        margin-top: 10px;
        position: relative;
        width: 300px;
    }
    .row-tip label{
        width: 300px;
        text-align: center;
        line-height: 31px;
    }
    .row-tip span{
        font-size: 12px;
        color: #707473;
        position: relative;
    }
    .row-tip .check{
        display: inline-block;
        width: 24px;
        height: 24px;
        border: 1px solid #ccc;
        box-sizing: border-box;
        line-height: 31px;
    }
    .row-tip input{
        position: absolute;
        margin: 0;
        left: 0;
        width: 24px;
        height: 24px;
        cursor:pointer;
    }
    .check-input{
        position: relative;
    }
    .check:visited{
        background-color: blue;
    }
    .select-phone>.select-phone-button{
        margin-top: 20px;
        display: flex;
        overflow: hidden;
        margin-bottom: 20px;
    }
    .select-phone>.select-phone-button button{
        width: 88px;
        height: 48px;
        font-size: 14px;
        box-sizing: border-box;
        padding: 0 15px;
        background-color: #f7f8f9;
        border-color: #ddd;
        border: 0;
    }
    .select-phone>.select-phone-button input{
        width: 220px;
        height: 48px;
        box-sizing: border-box;
        padding: 20px 0 0 10px;
        margin-top: 10px;
        margin: 0 auto;
        outline: none;
    }
    .d-input{
        margin-top: 20px;
    }
    .d-input >.d-input-button {
        border: 1px solid #ddd;
        display: flex;
    }
    .d-input >.d-input-button input{
        width: 151px;
        height: 46px;
        outline: none;
        border: 0;
    }
    .d-input >.d-input-button button{
        width: 130px;
        height: 34px;
        color: #fff;
        background: #44a8f2;
        border: 1px solid #44a8f2;
        text-align: center;
        position: relative;
        top: 6px;
        cursor: pointer;
        outline: none;
    }
    .register-button button{
        width: 300px;
        height: 48px;
        background-color: #44A8f2;
        margin: 20px 0 0 ;
        border: 0;
        cursor: pointer;
        color: white;
    }
    .register-button a{
        font-size: 14px;
        padding: 15px 0 30px;
        display: block;
    }
    .register-question-div{
        margin: 64px 0 0;
        padding: 0 0 40px;
    }
    .register-question-div div {
        font-size: 14px;
    }
    .register-question-div div>a{
        font-size: 14px;
    }
    .register-question-div div>:nth-child(1){
        padding: 0 8px 0 0;
        border-right: 1px solid rgba(0,0,0,.09);
    }
    .register-question-div div>:nth-child(2){
        padding: 0 0 0 8px;
    }
    .register-question-div :nth-child(2){
        margin-top: 8px;
    }
</style>
<script>
export default {
    data(){
        return{
            select:true,
            active:"true",
            dis:false,
            emailres:"",
            str1:"",
            str2:"",
            eupwd1:"",
            eupwd2:"",
        }
    },
    methods:{
        phone(){
            this.select=true;
            this.active="true"
        },
        email(){
            this.select=false;
            this.active="false"
        },
        check(){
            if(!this.dis){
                this.dis=true
            }else{
                this.dis=false
            }
        },
        res(){
            if(this.eupwd1==this.eupwd2 && this.emailres!=""){
                this.axios.post('/v1/reg',`email=${this.emailres}&upwd=${this.eupwd1}`).then(result=>{
                    if(result.data>0){
                        this.$router.push('login');
                    }
                })
            }else{
                this.str2 = "两次密码不一样"
            }
            
        }
    },
    watch:{
        emailres(){
            if(this.emailres!=""){
                var reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
                console.log(this.emailres)
                if(reg.test(this.emailres)){
                    this.str1 = "邮箱格式正确";
                }else{
                    this.str1 = "邮箱格式不正确"
                }
            }else{
                this.str1 = "邮箱不能为空"
            }

        },
        eupwd1(){
            if(this.eupwd1.length>=6){
                this.str2 = "√"
            }else if(this.eupwd1.length==0){
                this.str2 = "密码不能位空"
            }else{
                this.str2 = "密码格式不正确,大于6位"
            }
        }
    }
}
</script>