import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import MyHeader from "./components/MyHeader.vue"
import MyFooter from "./components/MyFooter.vue"
import Hd from "./components/Hd.vue"
import Card from "./components/Card.vue"
import BigCard from "./components/BigCard.vue"
import CardBig from "./components/CardBig.vue"
import CardBig2 from "./components/CardBig2.vue"
import CardBig3 from "./components/CardBig3.vue"
import CardChange from "./components/CardChange.vue"
import CardChange2 from "./components/CardChange2.vue"
import CardChange3 from "./components/CardChange3.vue"
import CardChange4 from "./components/CardChange4.vue"
import CardChange5 from "./components/CardChange5.vue"
import ShopCard from "./components/ShopCard.vue"
import Carousel from "./components/Carousel.vue"

import axios from 'axios'

axios.defaults.baseURL="http://127.0.0.1:3000/pro";
Vue.prototype.axios=axios;


Vue.config.productionTip = false

Vue.component("my-header",MyHeader)
Vue.component("my-footer",MyFooter)
Vue.component("my-hd",Hd)
Vue.component("my-card",Card)
Vue.component("big-card",BigCard)
Vue.component("card-big",CardBig)
Vue.component("card-big2",CardBig2)
Vue.component("card-big3",CardBig3)
Vue.component("card-change",CardChange)
Vue.component("card-change2",CardChange2)
Vue.component("card-change3",CardChange3)
Vue.component("card-change4",CardChange4)
Vue.component("card-change5",CardChange5)
Vue.component("shop-card",ShopCard)
Vue.component('carousel',Carousel)




new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
