<template>
  <div class="my-footer">
    <div style="margin-top: 72px">
      <div class="footer-header">
        <div class="footer-car">
          <p><img src="../../public/img/truck-moving.svg" alt="" /></p>
          <h4>全场满 ¥99 顺丰包邮<br />（顺丰无法配送的区域将使用 EMS）</h4>
        </div>
        <div class="footer-card">
          <p><img src="../../public/img/credit-card.svg" alt="" /></p>
          <h4>
            支持支付宝、微信、银联、银行转账<br />支持花呗、京东白条和招行分期
          </h4>
        </div>
        <div class="footer-mes">
          <p><img src="../../public/img/comment-alt-smile.svg" alt="" /></p>
          <h4>联系我们:<a href="">在线支持</a></h4>
        </div>
        <div class="footer-commercial">
          <p>
            <img src="https://szcert.ebs.org.cn/Images/newGovIcon.gif" alt="" />
          </p>
        </div>
      </div>
      <div class="footer-middle">
        <div class="middle-one">
          <h3>商城热卖</h3>
          <ul>
            <li><a href="">御 Mavic</a></li>
            <li><a href="">晓 Spark</a></li>
            <li><a href="">精灵 Phantom</a></li>
            <li><a href="">灵眸 Osmo</a></li>
            <li><a href="">悟 Inspire</a></li>
            <li><a href="">如影 Ronin</a></li>
          </ul>
        </div>
        <div class="middle-one">
          <h3>帮助与支持</h3>
          <ul>
            <li><a href="">支付方式</a></li>
            <li><a href="">订单帮助</a></li>
            <li><a href="">发货与物流</a></li>
            <li><a href="">退换货条款</a></li>
            <li><a href="">技术支持</a></li>
            <li><a href="">售后服务政策</a></li>
            <li><a href="">DJI 币返利计划</a></li>
          </ul>
        </div>
        <div class="middle-one">
          <h3>商城项目</h3>
          <ul>
            <li><a href="">以旧换新</a></li>
            <li><a href="">DJI 大疆商城 App</a></li>
          </ul>
        </div>
        <div class="middle-one">
          <h3>社区</h3>
          <ul>
            <li><a href="">天空之城</a></li>
            <li><a href="">DJI 大疆社区</a></li>
            <li><a href="">购机指南</a></li>
          </ul>
        </div>
        <div class="middle-one">
          <h3>订阅</h3>
          <div class="details">
            第一时间了解我们的促销活动、热销产品和最新信息。
          </div>
          <div>
            <input type="email" placeholder="请输入你的邮箱" />
            <button><i>></i></button>
          </div>
        </div>
      </div>
      <div class="footer-foot">
        <div class="footer-foot-top">
          <div class="footer-foot-top-left">
            <a href=""><img src="../../public/img/log.svg" alt="" /></a>
            <a href="">关于我们</a><a href="">联系我们</a><a href="">招聘精英</a
            ><a href="">官方旗舰店</a>
          </div>
          <div class="footer-foot-top-right">
            <a href=""><img src="../../public/img/youku.svg" alt=""></a>
            <a href=""><img src="../../public/img/weixin.svg" alt=""></a>
            <a href=""><img src="../../public/img/weibo.svg" alt=""></a>
          </div>
        </div>
        <div class="footer-foot-foot">
          <div class="footer-foot-foot-left">
            <span>Copyright © 2021 DJI 大疆创新 版权所有</span>
            <span>
              <a href="">隐私权政策</a>
              <a href="">使用条款</a>
              <a href="">粤ICP备12022215号-11</a>
              <a href="">营业执照</a>
              <a href="">网站地图</a>
            </span>
          </div>
          <div class="footer-foot-foot-right">网络问题反馈？<a href="">点击这里</a></div>
        </div>
      </div>
    </div>
  </div>
</template>
<style scoped>
*{
  box-sizing: content-box;
}
.my-footer{
  background-color: white;
}
.my-footer .footer-header {
  display: flex;
  width: 1200px;
  height: 200px;
  margin-left: auto;
  margin-right: auto;
  border-bottom: 1px solid #f0f1f2;
}
.footer-car {
  padding: 48px 0;
  margin-right: 16px;
  width: 292px;
  height: 200px;
}
.my-footer h4 {
  font-size: 14px;
  line-height: 24px;
  color: #6c7073;
}
.footer-card {
  padding: 48px 0;
  margin-right: 16px;
  width: 292px;
  height: 200px;
}
.footer-mes {
  padding: 48px 0;
  margin-right: 16px;
  width: 292px;
  height: 200px;
}
.footer-mes a {
  text-decoration: none;
}
.footer-commercial {
  padding: 48px 0;
  margin-right: 16px;
  width: 292px;
  height: 200px;
}
.footer-middle {
  display: flex;
  width: 1200px;
  height: 296px;
  margin-left: auto;
  margin-right: auto;
  padding-bottom: 48px;
  padding-top: 72px;
}
.middle-one {
  margin-right: 24px;
  width: 220px;
  text-align: left;
  height: 100%;
}
.middle-one .details {
  color: #6c7073;
  font-size: 12px;
  line-height: 16px;
  padding-bottom: 16px;
}
.middle-one ul {
  padding: 0;
}
.middle-one > h3 {
  line-height: 24px;
  margin-bottom: 8px;
  color: #3b3e40;
  font-size: 12px;
  font-weight: 500;
}
.middle-one li {
  list-style: none;
  margin-bottom: 8px;
  line-height: 24px;
}
.middle-one li a {
  font-size: 12px;
  color: #6c7073;
  text-decoration: none;
}
.middle-one li a:hover {
  color: #1897f2;
}
.middle-one input {
  display: inline-block;
  height: 32px;
  padding: 0 8px;
  width: 156px;
  font-size: 12px;
  font-family: open sans;
  line-height: 32px;
  color: #6c7073;
  background-color: #fff;
  background-image: none;
  border: 1px solid #d4d7d9;
  border-radius: 4px 0 0 4px;
}
.middle-one button {
  background-image: none;
  background-color: #6c7073;
  cursor: not-allowed;
  pointer-events: none;
  box-shadow: none;
}
.middle-one button > i {
  display: inline-block;
  font: normal normal normal 14px/1 FontAwesome;
  font-size: inherit;
  text-rendering: auto;
  -webkit-font-smoothing: antialiased;
}
.my-footer .footer-foot {
  display: flex;
  width: 1200px;
  height: 80px;
  margin-left: auto;
  margin-right: auto;
}
.footer-foot-top {
  display: flex;
  display: inline-block;
  height: 40px;
  width: 100%;
  margin-bottom: 16px;
  border-bottom: 1px solid #f0f1f2;
}
.footer-foot-top-left a {
  float: left;
  text-align: left;
  font-size: 12px;
  text-decoration: none;
  color: inherit;
  line-height: 24px;
  margin-right: 24px;
}
.footer-foot-top-right {
  float: right;
}
/* .footer-foot-top-right a {
  font-size: 12px;
  text-decoration: none;
  color: inherit;
  line-height: 24px;
  margin-right: 24px;
} */
.footer-foot-top-right img{
  margin: 0;
  /* padding: 0; */
  margin-left: 20px;
}
.footer-foot-foot{
  position: absolute;
  margin-top: 64px;
  /* width: 100%; */
}
.footer-foot-foot-left{
  float: left;
  text-align: left;
  font-weight: 400;
  font-size: 12px;
  color: #6c7073;
  height: 24px;
  width: 1070px; 
}
.footer-foot-foot span{
  font-size: 12px;
  line-height: 24px;
  margin-right: 30px;
}
.footer-foot-foot-left a{
  padding-right: 20px;
  text-decoration: none;
  color: #6c7073
}
.footer-foot-foot-right{
  float: right;
  /* position: absolute; */
  right: 0;
  font-size: 12px;
  line-height: 24px;
  color: #6c7073
}
.footer-foot-foot-right a{
  text-decoration: none;
  color: #6c7073
}
.footer-foot-top-left a:hover{
  color: #1897f2;
}
.footer-foot-foot-left a:hover{
  color: #1897f2;
}

</style>