<template>
  <div class="my-header">
    <div class="product">
      <div class="pruduct-header">
        <div class="section-container">
          <div class="float-left pruduct-header-left">
            <a href="" class="product-a">DJi大疆官网</a>
            <span>满 ¥99 顺丰包邮。下单即享 1% DJI币返点</span>
          </div>
          <div class="float-right pruduct-header-right">
            <span></span>
            <span>购物车</span>
            <span></span>
            <span class="divider">|</span>
            <router-link to="/login">登录</router-link>
            <span class="divider">|</span>
            <router-link to="/register">注册</router-link>
            <span class="divider">|</span>
            <a href="javascript;">中国大陆(简体中文/￥CNY)</a> 
          </div>
        </div>
      </div>
      <div class="pruduct-middle">
        <div class="section-container">
          <div class="middle-log">
            <div class="log">
              <img src="/img/log.svg" alt="">
            </div>
            <span>商城</span>
          </div>
          <div class="middle-list">
            <div>
              <ul class="middle-list-ul">
                <li class="list-drop-down"  @mouseenter="show" @mouseleave="showleave">商品分类↓
                  <!-- <ul class="middle-list-item">
                    <li>御Mavic></li>
                    <li>灵眸Osmo></li>
                    <li>精灵Phantom></li>
                    <li>如影Ronin></li>
                  </ul> -->
                </li>
                <li>以旧换新</li>
                <li>购机指南</li>
                <li>大疆商城app</li>
              </ul>
            </div>
          </div>
          <div class="middle-right">
            <div><input type="text" v-model="kw" placeholder="搜索商品..." @keydown.13="search"></div>
            <div class="middle-right-button iconfont icon-.icon-guanbi">
            <button @click="search"><img src="../../public/img/sousuo.svg" alt=""></button>
            </div>
          </div>
        </div>
      </div>
      <!-- <div class="middle-drop-down" v-show="down" @mouseenter="show" @mouseleave="showleave">
        <ul>
          <li>1
            <ul class="drop-down-ul">
              <li>1</li>
              <li>1</li>
              <li>1</li>
            </ul>
          </li>
          <li>1</li>
          <li>1</li>
          <li>1</li>
          <li>1</li>
        </ul>
      </div>  -->
      <div class="pruduct-footer">
        <div class="pruduct-footer-menu">
          <ul class="pruduct-footer-menu-item">
            <li v-for="(item,i) in items" :key="i">
              <img :src="`img/${item.img}`" alt="">
              <div>{{item.type}}</div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data(){
    return{
      down:false,
      items:[],
      kw:""
    }
  },
  methods:{
    show(){
      if(!this.down){
        this.down = true
      }else{
        this.down = false
      }
    },
    showleave(){
      if(this.down){
        this.down = false
      }else{
        this.down = true
      }
    },
    search(){
      this.$router.push({path:'/search/'+this.kw},onComplete => {},onAbort => {})
    }
  },
  created(){
    this.kw=this.$router.params.kw;
  },
  watch:{
    $router(){
      this.kw=this.$router.params.kw;
    }
  },
  mounted(){
    this.axios.get('/nav').then(result=>{
      this.items = result.data;
    })
  }
}
</script>
<style scoped>
  .my-header{
    background-color: white;
  }
  .pruduct-header{
    height: 40px;
    background-color: #f7f9fa;
    width: 100%;
  }
  .pruduct-header-left>a{
    font-size: 12px;
    color: #6c7073;
    line-height: 40px;
    margin: 8px 24px 8px 0;
    text-decoration:none
  }
  .pruduct-header-left>a:hover{
    color: #1897f2;
  }
  .pruduct-header-left>span{
    font-size: 12px;
    line-height: 40px;
    margin: 0 0 0 24px;
  }
  .pruduct-header-right>a{
    text-decoration:none;
    color: #6c7073;
    line-height: 40px;
    font-size: 12px;
  }
  .pruduct-header-right>span{
    font-size: 12px;
    color: #6c7073;
  }
  .pruduct-header-right>.divider{
    width: 24px;
    height: 12px;
    display: inline-block;
    text-align: center;
  }
  .pruduct-middle{
    height: 63px;
    border-bottom: 1px solid #f0f1f2;;
  }
  .middle-log>.log{
    display: inline-block;
    height: 63px;
  }
  .middle-log>.log img{
    text-align: center;
    padding: 20px 10px;
  }
  .middle-log>span{
    line-height: 63px;
    font-size: 18px;
  }
  .middle-right{
    position: relative;
    width: 282px;
  }
  .middle-right>input{
    width: 100%;
    height: 63px;
    padding: 12px 64px 12px 16px;
    border: none;
    background: #fff;
    font-size: 14px;
    font-family: Open Sans;
    font-weight: 400;
    outline: none;
    box-sizing: border-box;
    border-bottom: 1px solid #fff;
    transition: all .3s ease;
    border-radius: 0;
  }
  .middle-right>button:hover{
    border: 0;
    outline: none;
    background-color: #fff;
  }
  .middle-list{
    width: 780px;
    height: 64px;
  }
  .middle-list>div>ul{
    list-style: none;
  }
  .middle-list>div>ul>li{
    display: inline-block;
    line-height: 63px;
    margin-left: 40px;
  }
  .middle-list>div>ul>li>div>a {
    color: #6c7073;
    text-decoration:none;
    font-size: 14px;
  }
  .middle-list>div>ul>li>div>a:hover{
    color: #1897f2;
  }
  .middle-list-ul{
    display: flex;
  }
  .middle-list-ul li{
    font-size: 14px;
    list-style: none;
  }
  .list-drop-down{
    position: relative;
  }
  .list-drop-down:hover{
    border-bottom: 1px solid #1897f2;
  }
  .middle-list-item{
    /* display: none; */
    position:absolute;
    left: 0;
    width: 200px;
    background-color: red;
  }
  .middle-list-item li{
    text-align: left;
  }
  .section-container{
    margin-left: auto;
    margin-right: auto;
    width: 1200px;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
  }
  .middle-right>div>input{
    width: 100%;
    height: 48px;
    padding: 12px 64px 12px 16px;
    border: none;
    background: #fff;
    font-size: 14px;
    font-family: Open Sans;
    font-weight: 400;
    outline: none;
    box-sizing: border-box;
    border-bottom: 1px solid #fff;
    transition: all .3s ease;
    border-radius: 0;
  }
  .middle-right>div>input:focus{
    border-bottom: 1px solid #1897f2;
  }
  .middle-right-button{
    position: absolute;
    top: 0;
    right: 0;
    width: 48px;
    height: 48px;
  }
  .middle-right-button button{
    width: 100%;
    height: 100%;
    cursor: pointer;
    margin: 0;
    padding: 0;
    outline: none;
    border: none;
    background-color: transparent;
  }
  .middle-right-button img{
    cursor: pointer;
  }
  /* .list-drop-down:hover .middle-list-item{
    display: block;
  } */
  .pruduct-footer-menu-item{
    margin: 0 auto;
    width: 1200px;
    height: 112px;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    padding: 0;
  }
  .pruduct-footer-menu>.pruduct-footer-menu-item li{
    width: 120px;
    height: 112px;
    box-sizing: border-box;
    padding: 16px 0 15px;
    list-style: none;
    font-size: 12px;
  }
  .middle-list-ul{
    position: relative;
  }
  .middle-drop-down{
    position: absolute;
    background-color: red;
    width: 100%;
    top: 104px;
    z-index: 10;
  }
  .middle-drop-down>ul li{
    list-style: none;
  }
  .middle-drop-down .drop-down-ul{
    position: relative;
  }
</style>