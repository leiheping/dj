<template>
<div class="mycard">
  <div class="card" v-for="(item,i) in fw" :key="i">
    <a href="" class="card-a">
      <div class="card-item">
      <img :src="`img/${item.img}`" alt="">
      <div></div>
      <h4>{{item.type}}</h4>
      <span>{{item.price}}</span>
    </div>
    </a>
  </div>
</div>

</template>
<style>
  .mycard{
    display: flex;
    justify-content: space-between;
    width: 1200px;
    margin: 0 auoto;
  }
  .card{
    box-sizing: border-box;
    width: 288px;
    height: 420px;
    cursor: pointer;
  }
  .card>.card-a{
    text-decoration: none;
  }
  .card>:hover{
    box-shadow: 0 15px 10px -15px #333;
  }
  .card>.card-a>.card-item{
    box-sizing: border-box;
    width: 288px;
    height: 420px;
  }
  .card>.card-a>.card-item img{
    padding: 24px 16px 8px;
    width: 288px;
    height: 288px;
  }
  .card>.card-a>.card-item div{
    /* width: 100%; */
    height: 24px;
  }
  .card>.card-a>.card-item h4{
    padding: 0 24px;
    font-size: 18px;
    color: #3b3e40;
  }
  .card>.card-a>.card-item span{
    font-size: 14px;
    color: #3b3e40;
  }
</style>
<script>
export default {
  data(){
    return{
      fw:[],
    }
  },
  mounted(){
    this.axios('/fwshop').then(result=>{
      this.fw = result.data
    })
  }
}
</script>