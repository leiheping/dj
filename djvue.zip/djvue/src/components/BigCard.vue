<template>
  <div class="bigcard">
    <a href="" class="bigcard-a">
      <div class="bigcard-img">
        <p>DJI Care 随心续享<br>商城专属，双重保障</p>
      </div>
    </a>
    <a href="" class="bigcard-a">
      <div class="bigcard-img2">
        <p>DJI 以旧换新<br>闲置电子设备,抵价换新机</p>
      </div>
    </a>
  </div>
</template>
<style scoped>
  *{
    margin: 0;
    padding: 0;
  }
  .bigcard {
    width: 592px;
    height: 400px;
  }
  .bigcard>.bigcard-a:hover {
    box-shadow: 0 15px 10px -15px #333;
  }
  .bigcard>.bigcard-a{
    text-decoration: none;
    color: #3b3e40;
  }
  .bigcard>.bigcard-a>.bigcard-img{
    width: 592px;
    height: 400px;
    background-repeat:no-repeat;
    background-size: cover;
    position: relative;
    background-image:url(../../public/img/8193accf66654676425ca7c303d37c77.jpg);
  }
  .bigcard>.bigcard-a>.bigcard-img>p{
    position:absolute;
    top: 48px;
    text-align: center;
    font-size: 24px;
    line-height: 32px;
    width: 100%;
  }
    .bigcard>.bigcard-a>.bigcard-img2{
    width: 592px;
    height: 400px;
    background-repeat:no-repeat;
    background-size: cover;
    position: relative;
    right: 0;
    background-image:url(../../public/img/09d17ceef4e862a7fa50038c9d81cc6e.png);
  }
  .bigcard>.bigcard-a>.bigcard-img2>p{
    position:absolute;
    top: 48px;
    text-align: center;
    font-size: 24px;
    line-height: 32px;
    width: 100%;
  }
</style>
<script>
export default {
  
}
</script>