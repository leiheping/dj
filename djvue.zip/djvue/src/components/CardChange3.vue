<template>
<div class="my-card-change">
  <div class="card-change" v-for="(item,i) in cardchangge" :key="i">
    <a href="" class="card-change-a" >
      <div class="card-change-bg">
        <div class="card-change-bgpic" :style="[{backgroundImage:'url('+ `/img/${(item.changeimg)}` +')'}]"></div>
        <div class="card-change-pic" :style="[{backgroundImage:'url('+ `/img/${(item.img)}` +')'}]"></div>
        <span>{{item.title}}</span>
      </div>
      <div class="card-change-kb"></div>
      <h3>{{item.type}}</h3>
      <div class="card-change-price">
        <span>{{`￥${item.price}`}}</span>
      </div>
    </a>
  </div>
</div>

</template>
<style scoped>
.card-change-bgpic{
  display: none;
}
.card-change-bg span{
  display: none;
}
.card-change-bg:hover .card-change-bgpic{
  display: block;
}
.card-change-bg:hover span{
  display: block;
}
.card-change-bg:hover .card-change-pic{
  display: none;
}
.my-card-change{
  display: flex;
  justify-content: space-between;
  width: 1200px;
  margin: 10px auto;
  flex-wrap:wrap;
}
  .card-change{
    width: 288px;
    height: 420px;
    margin-top: 12px;
    text-align: center;
    box-sizing: border-box;
    cursor: pointer;
    background-color: white;
  }
  .card-change>.card-change-a{
    text-decoration: none;
    color: #3b3e40;
  }
  .card-change:hover{
    box-shadow: 0 15px 10px -15px #333;
  }
  .card-change>.card-change-a>.card-change-bg{
    width: 100%;
    height: 288px;
    position: relative;
  }
  .card-change>.card-change-a>.card-change-bg>.card-change-pic{
    width: 100%;
    height: 100%;
    background-repeat:no-repeat;
    background-size: cover;
    position: relative;
  }
  .card-change>.card-change-a>.card-change-bg>.card-change-bgpic{
    width: 100%;
    height: 100%;
    background-repeat:no-repeat;
    background-size: cover;
    background-position: 50%;
    position:absolute;
  }
  .card-change>.card-change-a>.card-change-bg>span{
    font-size: 14px;
    position:absolute;
    bottom: 0;
    color: white;
    left: 50%;
    right: 50%;
    margin-left: -144px;
    margin-right: -144px;
  }
  .card-change>.card-change-a>.card-change-kb{
    width: 100%;
    height: 24px;
  }
  .card-change>.card-change-a>h3{
    width: 100%;
    height: 48px;
    margin: 8px 0;
    padding: 0 24px;
    font-size: 18px;
  }
  .card-change>.card-change-a>.card-change-price>span{
    font-size: 14px;
  }
</style>
<script>
export default {
  data(){
    return{
      show:false,
      cardchangge:[],
    }
  },
  mounted(){
    this.axios.get(`shop/3`).then(result=>{
      this.cardchangge = result.data;
    })
  }
}
</script>