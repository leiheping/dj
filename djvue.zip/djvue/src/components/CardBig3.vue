<template>
  <div class="card-big">
    <router-link to="/details/5" class="card-big-a" @mouseenter="show" @mouseleave="shownone">
      <div class="card-big-bg">
        <div class="card-big-bgpic" v-show="!showclass" style="background-image: url(/img/47d474d01c89d1536cf03744b28a6933.png);"></div>
        <div class="card-big-top" v-show="showclass" style="background-image: url(/img/3bdc20dc3ff429a75cc10a3d6d9e2d9a.png);"></div>
        <div class="card-big-foot" v-show="showclass">
          <img src="../../public/img/379a6fc31f016bcd7ce5d28df26d99ea.png" alt="">
        </div>
      </div>
      <div class="card-big-middle">
        <div class="card-big-title">
          <div class="card-big-title-kb"></div>
          <div class="card-big-title-h2"><h2>DJImini2</h2></div>
          <div class="card-big-title-span"><span>轻巧便携</span><span>4k视频</span><span>31分钟续航</span></div>
          <div class="card-big-title-title">小巧但性能犀利，可拍摄4K视频，实现4倍变焦，最远10公里控制距离。一键短片、一键全景，一键直出大片。智能易用，航拍轻而易举。</div>
          <div class="card-big-title-price"><span>￥2899</span></div>
        </div>
      </div>
    </router-link>
  </div>
</template>
<style scoped>
  .card-big {
    width: 390px;
    height: 547px;
    text-align: center;
    position: relative;
    cursor: pointer;
    background-color: white;
  }
  .card-big>.card-big-a{
    text-decoration: none;
    color: #3e3b40;
  }
  .card-big:hover{
    box-shadow: 0 15px 10px -15px #333;
  }
  .card-big>.card-big-a>.card-big-bg{
    width: 100%;
    height: 264px;
    position: absolute;
  }
  .card-big>.card-big-a>.card-big-bg>.card-big-bgpic{
    background-size: cover;
    width: 100%;
    height: 264px;
    position: absolute;
  }
  .card-big>.card-big-a>.card-big-bg>.card-big-top{
    width: 100%;
    height: 160px;
    background-size: cover;
  }
  .card-big>.card-big-a>.card-big-bg>.card-big-foot{
    width: 264px;
    height: 176px;
    margin-left: -132px;
    margin-left: -132px;
    position: absolute;
    top: 72px;
    left: 50%;
  }
  .card-big>.card-big-a>.card-big-bg>.card-big-foot>img{
    width: 100%;
    height: 100%;
  }
  .card-big>.card-big-a>.card-big-middle{
    position: absolute;
    width: 100%;
    height: 100%;
    z-index: 1;
  }
  .card-big>.card-big-a>.card-big-middle>.card-big-title {
    padding-top: 264px;
    width: 100%;
    position: relative;
  }
  .card-big>.card-big-a>.card-big-middle>.card-big-title>.card-big-title-kb{
    height: 27px;
  }
  .card-big>.card-big-a>.card-big-middle>.card-big-title>.card-big-title-h2 h2{
    height: 40px;
    line-height: 40px;
    font-size: 28px;
    padding: 0 24px;
  }
  .card-big>.card-big-a>.card-big-middle>.card-big-title>.card-big-title-span{
    margin-top: 8px;
    padding: 0 24px;
    font-size: 12px;
  }
  .card-big>.card-big-a>.card-big-middle>.card-big-title>.card-big-title-span span{
    margin-right: 10px;
  }
  .card-big>.card-big-a>.card-big-middle>.card-big-title>.card-big-title-title{
    font-size: 14px;
    margin: 16px 0 0;
    padding: 0 24px;
  }
  .card-big>.card-big-a>.card-big-middle>.card-big-title>.card-big-title-price{
    position: absolute;
    bottom: -48px;
    font-size: 16px;
    left: 50%;
    margin-left: -30px;
  }
</style>
<script>
export default {
  data(){
    return{
      showclass:true
    }
  },
  methods:{
    show(){
      if(this.showclass){
        this.showclass = false
      }
    },
    shownone(){
      if(!this.showclass){
        this.showclass = true;
      }
    }
  }
}
</script>