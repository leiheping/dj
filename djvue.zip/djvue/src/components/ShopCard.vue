<template>
<div class="show">
  <div class="shopcard" v-for="(item,i) in items" :key="i">
    <div class="shopcard-middle">
      <div class="shopcard-middle-fw">
        <div style="float: left;">{{item.sort}}</div>
        <a href="" style="float: right;">更多></a>
      </div>
      <div class="shopcard-middle-video">
        <div class="shopcard-title">
          <a href="">
            <div class="shopcard-title-pic">
              <img :src="`img/${item.img}`" alt="">
            </div>
            <div class="shopcard-title-title">
              <h4>{{item.type}}</h4>
              <p>{{item.title}}</p>
              <div>
                <span>{{`￥${item.price}`}}</span>
              </div>
            </div>
          </a>
        </div>
        <div class="shopcard-video">
          <video height="100%" autoplay loop muted :src="`/img/${item.video}`">
          </video>
        </div>
      </div>
      <div class="shopcard-middle-card">
        <ul>
          <li>
            <card-change v-if="i==0"></card-change>
            <card-change2 v-else-if="i==1"></card-change2>
            <card-change3 v-else-if="i==2"></card-change3>
            <card-change4 v-else-if="i==3" class="change4"></card-change4>
            <card-change5 v-else></card-change5>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>

</template>
<style scoped>
  *{
    margin: 0;
    padding: 0;
  }
  .show{
    background-color: #f0f1f2;
  }
  .shopcard{
    position: relative;
  }
  .shopcard>.shopcard-middle{
    height: 100%;
    width: 1200px;
    margin: 48px auto;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-fw{
    width: 100%;
    height: 48px;
    line-height: 48px;
    text-align: center;
    margin: 0 0 16px;
    font-size: 32px;
    color: #3b3e40;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-fw a{
    text-decoration: none;
    font-size: 16px;
    color: #3b3e40;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-fw a:hover{
    color: #1897f2;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-video{
    width: 100%;
    height: 400px;
    display: flex;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-video>.shopcard-video{
    width: 600px;
    height: 100%;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-video>.shopcard-title{
    width: 600px;
    height: 100%;
    background-color: white;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-card{
    width: 100%;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-card>ul{
    display: block;
    display: flex;
    max-width: 1200px;
    flex-wrap: wrap;
    justify-content: space-between;
    width: 100%;
    height: 872px;
  }
  .shopcard>.shopcard-middle>.shopcard-middle-card>ul>li{
    display: inline-block;
    width: 288px;
    height: 420px;
    margin: 16px 0;
  }
  .shopcard-middle-video>.shopcard-title>a{
    display: block;
  }
  .shopcard-middle-video>.shopcard-title>a>.shopcard-title-pic{
    width: 264px;
    margin: 0 24px;
    height: 264px;
    float: left;
    margin-top: 68px;
  }
  .shopcard-middle-video>.shopcard-title>a>.shopcard-title-pic>img{
    width: 264px;
    height: 264px;
  }
  .shopcard-middle-video>.shopcard-title>a>.shopcard-title-title{
    margin-right: 24px;
    width: 264px;
    height: 264px;
    float: right;
    margin-top: 120px;
  }
  .shopcard-middle-video>.shopcard-title>a>.shopcard-title-title h4{
    font-size: 24px;
    color: #3b3e40;
    margin: 0 0 16px;
  }
  .shopcard-middle-video>.shopcard-title>a>.shopcard-title-title p{
    font-size: 14px;
    color: #3b3e40;
    margin: 0 0 24px;
  }
  .shopcard-middle-video>.shopcard-title>a>.shopcard-title-title div span{
    font-size:16px;
    color: #3b3e40;
  }
  .shopcard-title:hover{
    box-shadow: 0 15px 10px -15px #333;
  }
</style>
<script>
import CardChange from './CardChange.vue'
export default {
  components: { CardChange },
  data(){
    return{
      items:[]
    }
  },
  mounted(){
    this.axios.get('/show').then(result=>{
      console.log(result.data)
      this.items = result.data;
    })
  }
}
</script>